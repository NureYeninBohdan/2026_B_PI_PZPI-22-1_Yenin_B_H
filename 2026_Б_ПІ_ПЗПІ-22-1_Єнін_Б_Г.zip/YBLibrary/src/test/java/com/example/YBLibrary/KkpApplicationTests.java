package com.example.YBLibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KkpApplicationTests {

    @Test
    void contextLoads() {
    }

}
