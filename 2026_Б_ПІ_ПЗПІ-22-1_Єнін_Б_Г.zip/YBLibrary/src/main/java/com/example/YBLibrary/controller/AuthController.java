package com.example.YBLibrary.controller;

import com.example.YBLibrary.service.UserService;
import com.example.YBLibrary.service.UserService.RegistrationConfirmationInfo;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    @GetMapping("/login")
    public String showLoginForm(@RequestParam(value = "error", required = false) String error,
                                @RequestParam(value = "unverified", required = false) String unverified,
                                @RequestParam(value = "registered", required = false) String registered,
                                @RequestParam(value = "confirmed", required = false) String confirmed,
                                Model model) {
        if (unverified != null) {
            model.addAttribute("errorMessage", "Акаунт ще не підтверджено. Перевірте email і перейдіть за посиланням підтвердження.");
        } else if (error != null) {
            model.addAttribute("errorMessage", "Невірне ім’я користувача або пароль");
        }

        if (registered != null) {
            model.addAttribute("successMessage", "Реєстрацію створено. Перевірте email для підтвердження акаунта.");
        }

        if (confirmed != null) {
            model.addAttribute("successMessage", "Email підтверджено. Тепер ви можете увійти в акаунт.");
        }

        return "loginpage";
    }

    @GetMapping("/register")
    public String showRegisterForm() {
        return "register";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    @PostMapping("/register")
    public String processRegistration(@RequestParam String username,
                                      @RequestParam String email,
                                      @RequestParam String password,
                                      Model model) {
        try {
            userService.registerUser(username, email, password);

            model.addAttribute(
                    "successMessage",
                    "Реєстрацію створено. Ми надіслали лист підтвердження на вашу email-адресу."
            );

            return "register";
        } catch (IllegalArgumentException | IllegalStateException e) {
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("username", username);
            model.addAttribute("email", email);

            return "register";
        }
    }

    @GetMapping("/registration/confirm")
    public String showRegistrationConfirmation(@RequestParam("token") String token,
                                               Model model) {
        try {
            RegistrationConfirmationInfo info = userService.getRegistrationConfirmationInfo(token);

            model.addAttribute("token", token);
            model.addAttribute("username", info.getUsername());
            model.addAttribute("maskedEmail", info.getMaskedEmail());
            model.addAttribute(
                    "message",
                    "Підтвердіть email-адресу для створення акаунта YBLibrary."
            );
            model.addAttribute("buttonText", "Підтвердити акаунт");
        } catch (IllegalArgumentException | IllegalStateException e) {
            model.addAttribute("errorMessage", e.getMessage());
        }

        return "registration-confirm";
    }

    @PostMapping("/registration/confirm")
    public String confirmRegistration(@RequestParam("token") String token,
                                      Model model) {
        try {
            userService.confirmRegistrationEmail(token);

            model.addAttribute(
                    "successMessage",
                    "Email успішно підтверджено. Тепер ви можете увійти в акаунт."
            );
        } catch (IllegalArgumentException | IllegalStateException e) {
            model.addAttribute("errorMessage", e.getMessage());
        }

        return "registration-confirm";
    }

    @PostMapping("/registration/resend")
    public String resendRegistrationConfirmation(@RequestParam String email,
                                                 Model model) {
        try {
            userService.resendRegistrationConfirmationEmail(email);

            model.addAttribute(
                    "successMessage",
                    "Ми повторно надіслали лист підтвердження. Перевірте вашу пошту."
            );
        } catch (IllegalArgumentException | IllegalStateException e) {
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("email", email);
        }

        return "register";
    }
}