package com.example.YBLibrary.service;

import com.example.YBLibrary.dto.CommentDTO;
import com.example.YBLibrary.model.Comment;
import com.example.YBLibrary.model.CommentReaction;
import com.example.YBLibrary.model.User;
import com.example.YBLibrary.repository.CommentReactionRepository;
import com.example.YBLibrary.repository.CommentRepository;
import com.example.YBLibrary.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

@Service
public class CommentService {

    private static final String DEFAULT_AVATAR = "/uploads/avatars/No Avatar.jpeg";

    private final CommentRepository commentRepo;
    private final UserRepository userRepo;
    private final CommentReactionRepository commentReactionRepo;

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public CommentService(CommentRepository commentRepo,
                          UserRepository userRepo,
                          CommentReactionRepository commentReactionRepo) {
        this.commentRepo = commentRepo;
        this.userRepo = userRepo;
        this.commentReactionRepo = commentReactionRepo;
    }

    @Transactional(readOnly = true)
    public List<CommentDTO> getCommentsForBook(Long bookId, Long currentUserId, boolean isAdmin) {
        return commentRepo.findByBookIdOrderBySentAtDesc(bookId).stream()
                .map(c -> toDto(c, currentUserId, isAdmin))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<CommentDTO> findByBookId(Long bookId) {
        return commentRepo.findByBookIdOrderBySentAtDesc(bookId).stream()
                .map(c -> toDto(c, null, false))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<CommentDTO> findByBookId(Long bookId, Long currentUserId, boolean isAdmin) {
        return commentRepo.findByBookIdOrderBySentAtDesc(bookId).stream()
                .map(c -> toDto(c, currentUserId, isAdmin))
                .toList();
    }

    @Transactional
    public CommentDTO addComment(Long bookId, Long userId, String content) {
        User user = userRepo.findById(userId).orElseThrow();

        Comment comment = new Comment();
        comment.setBookId(bookId);
        comment.setUserId(userId);
        comment.setComment(content == null ? "" : content.trim());

        Comment saved = commentRepo.save(comment);

        return new CommentDTO(
                saved.getCommentId(),
                saved.getComment(),
                saved.getSentAt().format(DATE_FMT),
                user.getUsername(),
                user.getUsername(),
                true,
                resolveAvatar(user),
                0,
                0,
                null
        );
    }

    @Transactional
    public void deleteComment(Long commentId, Long userId, boolean isAdmin) {
        Comment comment = commentRepo.findById(commentId).orElseThrow();

        boolean owner = comment.getUserId() != null && Objects.equals(comment.getUserId(), userId);

        if (isAdmin || owner) {
            commentRepo.delete(comment);
        } else {
            throw new SecurityException("Немає прав видаляти цей коментар");
        }
    }

    private CommentDTO toDto(Comment c, Long currentUserId, boolean isAdmin) {
        User u = userRepo.findById(c.getUserId()).orElseThrow();

        String username = u.getUsername();
        String avatarUrl = resolveAvatar(u);

        boolean canDelete = currentUserId != null &&
                (isAdmin || Objects.equals(u.getUserId(), currentUserId));

        long likeCount = commentReactionRepo.countByCommentIdAndReactionType(
                c.getCommentId(),
                CommentReaction.TYPE_LIKE
        );

        long dislikeCount = commentReactionRepo.countByCommentIdAndReactionType(
                c.getCommentId(),
                CommentReaction.TYPE_DISLIKE
        );

        String currentUserReaction = null;

        if (currentUserId != null) {
            currentUserReaction = commentReactionRepo
                    .findByCommentIdAndUserId(c.getCommentId(), currentUserId)
                    .map(CommentReaction::getReactionType)
                    .orElse(null);
        }

        return new CommentDTO(
                c.getCommentId(),
                c.getComment(),
                c.getSentAt().format(DATE_FMT),
                username,
                username,
                canDelete,
                avatarUrl,
                likeCount,
                dislikeCount,
                currentUserReaction
        );
    }

    private String resolveAvatar(User u) {
        String path = u.getAvatarPath();

        if (path == null || path.trim().isEmpty()) {
            return DEFAULT_AVATAR;
        }

        return path;
    }
}