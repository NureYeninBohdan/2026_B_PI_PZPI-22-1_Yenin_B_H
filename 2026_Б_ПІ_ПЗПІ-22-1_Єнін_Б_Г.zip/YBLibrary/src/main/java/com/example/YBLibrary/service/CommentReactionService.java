package com.example.YBLibrary.service;

import com.example.YBLibrary.dto.CommentReactionDTO;
import com.example.YBLibrary.model.Comment;
import com.example.YBLibrary.model.CommentReaction;
import com.example.YBLibrary.repository.CommentReactionRepository;
import com.example.YBLibrary.repository.CommentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;

@Service
public class CommentReactionService {

    private final CommentRepository commentRepository;
    private final CommentReactionRepository commentReactionRepository;

    public CommentReactionService(CommentRepository commentRepository,
                                  CommentReactionRepository commentReactionRepository) {
        this.commentRepository = commentRepository;
        this.commentReactionRepository = commentReactionRepository;
    }

    @Transactional
    public CommentReactionDTO toggleReaction(Long bookId,
                                             Long commentId,
                                             Long userId,
                                             String reactionType) {
        if (bookId == null) {
            throw new IllegalArgumentException("ID книги не задано");
        }

        if (commentId == null) {
            throw new IllegalArgumentException("ID коментаря не задано");
        }

        if (userId == null) {
            throw new IllegalArgumentException("ID користувача не задано");
        }

        String normalizedReactionType = normalizeReactionType(reactionType);

        Comment comment = commentRepository.findById(commentId)
                .orElseThrow(() -> new IllegalArgumentException("Коментар не знайдено"));

        if (!Objects.equals(comment.getBookId(), bookId)) {
            throw new IllegalArgumentException("Коментар не належить цій книзі");
        }

        commentReactionRepository.findByCommentIdAndUserId(commentId, userId)
                .ifPresentOrElse(existingReaction -> {
                    if (normalizedReactionType.equals(existingReaction.getReactionType())) {
                        commentReactionRepository.delete(existingReaction);
                    } else {
                        existingReaction.setReactionType(normalizedReactionType);
                        commentReactionRepository.save(existingReaction);
                    }
                }, () -> {
                    CommentReaction reaction = new CommentReaction();
                    reaction.setCommentId(commentId);
                    reaction.setUserId(userId);
                    reaction.setReactionType(normalizedReactionType);
                    commentReactionRepository.save(reaction);
                });

        return buildReactionDto(commentId, userId);
    }

    @Transactional(readOnly = true)
    public CommentReactionDTO getReactionInfo(Long commentId, Long userId) {
        if (commentId == null) {
            throw new IllegalArgumentException("ID коментаря не задано");
        }

        return buildReactionDto(commentId, userId);
    }

    private CommentReactionDTO buildReactionDto(Long commentId, Long userId) {
        long likeCount = commentReactionRepository.countByCommentIdAndReactionType(
                commentId,
                CommentReaction.TYPE_LIKE
        );

        long dislikeCount = commentReactionRepository.countByCommentIdAndReactionType(
                commentId,
                CommentReaction.TYPE_DISLIKE
        );

        String currentUserReaction = null;

        if (userId != null) {
            currentUserReaction = commentReactionRepository
                    .findByCommentIdAndUserId(commentId, userId)
                    .map(CommentReaction::getReactionType)
                    .orElse(null);
        }

        return new CommentReactionDTO(
                commentId,
                likeCount,
                dislikeCount,
                currentUserReaction
        );
    }

    private String normalizeReactionType(String reactionType) {
        if (reactionType == null || reactionType.isBlank()) {
            throw new IllegalArgumentException("Тип реакції не задано");
        }

        String normalized = reactionType.trim().toUpperCase();

        if (!CommentReaction.TYPE_LIKE.equals(normalized)
                && !CommentReaction.TYPE_DISLIKE.equals(normalized)) {
            throw new IllegalArgumentException("Некоректний тип реакції");
        }

        return normalized;
    }
}