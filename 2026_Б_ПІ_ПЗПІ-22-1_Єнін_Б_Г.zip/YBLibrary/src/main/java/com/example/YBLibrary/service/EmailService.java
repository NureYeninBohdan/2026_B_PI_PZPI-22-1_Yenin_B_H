package com.example.YBLibrary.service;

import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;
import com.sendgrid.helpers.mail.objects.Personalization;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    private final SendGrid sendGrid;
    private final String fromEmail;

    @Autowired
    public EmailService(SendGrid sendGrid,
                        @Value("${sendgrid.from.email:${sendgrid.from-email:bohdan.ienin@nure.ua}}") String fromEmail) {
        this.sendGrid = sendGrid;
        this.fromEmail = fromEmail;
    }

    public boolean sendEmail(String to, String subject, String contentText) {
        logger.info("Sending plain text email");

        if (!isEmailConfigValid(to)) {
            return false;
        }

        Email from = new Email(fromEmail);
        Email toEmail = new Email(to);
        Content content = new Content("text/plain", contentText == null ? "" : contentText);
        Mail mail = new Mail(from, subject, toEmail, content);

        return sendMail(mail, "plain text");
    }

    public boolean sendHtmlEmail(String to,
                                 String subject,
                                 String htmlContent,
                                 String plainTextFallback) {
        logger.info("Sending HTML email");

        if (!isEmailConfigValid(to)) {
            return false;
        }

        Mail mail = new Mail();
        mail.setFrom(new Email(fromEmail));
        mail.setSubject(subject == null ? "" : subject);

        Personalization personalization = new Personalization();
        personalization.addTo(new Email(to));
        mail.addPersonalization(personalization);

        mail.addContent(new Content("text/plain", plainTextFallback == null ? "" : plainTextFallback));
        mail.addContent(new Content("text/html", htmlContent == null ? "" : htmlContent));

        return sendMail(mail, "HTML");
    }

    private boolean isEmailConfigValid(String to) {
        if (sendGrid == null) {
            logger.error("SendGrid instance is NULL, cannot send email.");
            return false;
        }

        if (to == null || to.isBlank()) {
            logger.error("Recipient email is empty, cannot send email.");
            return false;
        }

        if (fromEmail == null || fromEmail.isBlank()) {
            logger.error("Sender email is empty, cannot send email.");
            return false;
        }

        return true;
    }

    private boolean sendMail(Mail mail, String emailType) {
        Request request = new Request();

        try {
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            Response response = sendGrid.api(request);

            int status = response.getStatusCode();

            logger.info("SendGrid {} email response status: {}", emailType, status);
            logger.debug("SendGrid response body: {}", response.getBody());
            logger.debug("SendGrid response headers: {}", response.getHeaders());

            if (status >= 200 && status < 300) {
                logger.info("{} email successfully sent", emailType);
                return true;
            }

            logger.error(
                    "Failed to send {} email. Status: {}, Body: {}",
                    emailType,
                    status,
                    response.getBody()
            );

            return false;
        } catch (IOException ex) {
            logger.error("Exception occurred while sending {} email", emailType, ex);
            return false;
        }
    }
}