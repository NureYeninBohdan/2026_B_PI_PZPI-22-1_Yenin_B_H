package com.example.YBLibrary.controller;

import com.example.YBLibrary.dto.UserSearchDTO;
import com.example.YBLibrary.model.User;
import com.example.YBLibrary.repository.UserRepository;
import com.example.YBLibrary.service.SubscriptionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/profiles")
public class ProfileSearchController {

    private static final String NO_AVATAR_PATH = "/uploads/avatars/No Avatar.jpeg";

    private final UserRepository userRepository;
    private final SubscriptionService subscriptionService;

    public ProfileSearchController(UserRepository userRepository,
                                   SubscriptionService subscriptionService) {
        this.userRepository = userRepository;
        this.subscriptionService = subscriptionService;
    }

    @GetMapping("/search")
    public List<UserSearchDTO> searchProfiles(@RequestParam("q") String query) {
        String normalizedQuery = query == null ? "" : query.trim();

        if (normalizedQuery.length() < 2) {
            return List.of();
        }

        return userRepository.findTop10ByUsernameContainingIgnoreCaseAndEmailVerifiedTrue(normalizedQuery)
                .stream()
                .map(this::toDto)
                .toList();
    }

    private UserSearchDTO toDto(User user) {
        String avatarUrl = user.getAvatarPath();

        if (avatarUrl == null || avatarUrl.isBlank()) {
            avatarUrl = NO_AVATAR_PATH;
        }

        boolean subscribed = subscriptionService.hasActiveSubscription(user.getUserId());

        return new UserSearchDTO(
                user.getUserId(),
                user.getUsername(),
                avatarUrl,
                subscribed
        );
    }
}