package com.example.YBLibrary.repository;

import com.example.YBLibrary.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    Optional<User> findByEmail(String email);

    List<User> findTop10ByUsernameContainingIgnoreCaseAndEmailVerifiedTrue(String query);

    Optional<User> findByResetToken(String resetToken);

    Optional<User> findByEmailVerificationToken(String emailVerificationToken);

    Optional<User> findByEmailChangeToken(String emailChangeToken);
    Optional<User> findByUsernameAndEmailVerifiedTrue(String username);

    boolean existsByEmail(String email);

    boolean existsByUsername(String username);
}