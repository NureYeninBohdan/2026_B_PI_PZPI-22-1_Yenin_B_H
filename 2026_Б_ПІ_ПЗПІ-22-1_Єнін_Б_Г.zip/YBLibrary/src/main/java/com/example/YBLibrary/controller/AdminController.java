package com.example.YBLibrary.controller;

import com.example.YBLibrary.model.Book;
import com.example.YBLibrary.repository.BookRepository;
import com.example.YBLibrary.service.BookDeleteService;
import net.coobird.thumbnailator.Thumbnails;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.nio.file.*;
import java.util.Map;
import java.util.UUID;

@Controller
@RequestMapping("/admin")
@PreAuthorize("hasAuthority('ADMIN')")
public class AdminController {

    private final BookDeleteService bookDeleteService;
    private final BookRepository bookRepository;

    private static final String COVER_UPLOAD_DIR = "uploads/covers";
    private static final String BOOK_FILE_UPLOAD_DIR = "uploads/books";
    private static final String NO_COVER_FILENAME = "No Cover.jpg";
    private static final String NO_COVER_PATH = "/uploads/covers/" + NO_COVER_FILENAME;

    public AdminController(BookDeleteService bookDeleteService,
                           BookRepository bookRepository) {
        this.bookDeleteService = bookDeleteService;
        this.bookRepository = bookRepository;
    }



    @PostMapping("/books/create")
    public String createBook(@RequestParam String title,
                             @RequestParam(required = false) String author,
                             @RequestParam(required = false) String description,
                             @RequestParam(required = false) String genre,
                             @RequestParam(required = false) String publishYear,
                             @RequestParam(required = false, defaultValue = "FREE") String accessLevel,
                             @RequestParam(required = false) MultipartFile coverFile,
                             @RequestParam(required = false) MultipartFile bookFile) throws IOException {

        String normalizedTitle = limitLength(emptyToNull(title), 500);

        if (normalizedTitle == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Назва книги є обов'язковою");
        }

        Book book = new Book();

        book.setTitle(normalizedTitle);
        book.setAuthor(limitLength(emptyToNull(author), 255));
        book.setDescription(emptyToNull(description));
        book.setGenre(limitLength(emptyToNull(genre), 255));
        book.setPublishYear(parsePublishYear(publishYear));
        book.setAccessLevel(normalizeAccessLevel(accessLevel));

        book.setAverageRating(0.0);
        book.setPopularity(0L);

        book.setBookDumpId(null);

        bookRepository.save(book);

        updateCover(book, coverFile, null);
        updateBookFile(book, bookFile, null);

        if (isCoverMissing(book.getCoverPath())) {
            book.setCoverPath(NO_COVER_PATH);
        }

        bookRepository.save(book);

        return "redirect:/books/" + book.getBookId();
    }

    @PostMapping("/delete-book")
    public ResponseEntity<String> deleteBook(@RequestBody Map<String, String> body,
                                             @AuthenticationPrincipal UserDetails userDetails) {
        if (userDetails == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Користувач не авторизований");
        }

        String bookIdStr = body.get("bookId");

        if (bookIdStr == null || bookIdStr.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("Невірний ID книги");
        }

        try {
            Long bookId = Long.parseLong(bookIdStr.trim());
            bookDeleteService.deleteBookById(bookId);
            return ResponseEntity.ok("Книгу успішно видалено");
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body("Невірний формат ID книги");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Помилка при видаленні: " + e.getMessage());
        }
    }

    @GetMapping("/books/{id}/edit")
    public String showEditBookForm(@PathVariable Long id,
                                   Model model) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Книга не знайдена"));

        if (isCoverMissing(book.getCoverPath())) {
            book.setCoverPath(NO_COVER_PATH);
        }

        if (book.getAccessLevel() == null || book.getAccessLevel().isBlank()) {
            book.setAccessLevel("FREE");
        }

        String bookFileName = null;

        if (book.getFilePath() != null && !book.getFilePath().isBlank()) {
            bookFileName = Paths.get(book.getFilePath()).getFileName().toString();
        }

        model.addAttribute("book", book);
        model.addAttribute("bookFileName", bookFileName);

        return "book-edit";
    }

    @PostMapping("/books/{id}/edit")
    public String saveBookEdits(@PathVariable Long id,
                                @RequestParam String title,
                                @RequestParam(required = false) String author,
                                @RequestParam(required = false) String description,
                                @RequestParam(required = false) String genre,
                                @RequestParam(required = false) String publishYear,
                                @RequestParam(required = false, defaultValue = "FREE") String accessLevel,
                                @RequestParam(required = false) MultipartFile coverFile,
                                @RequestParam(required = false) MultipartFile bookFile,
                                @RequestParam(required = false) String deleteCover,
                                @RequestParam(required = false) String deleteBookFile) throws IOException {

        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Книга не знайдена"));

        String normalizedTitle = limitLength(emptyToNull(title), 500);

        if (normalizedTitle == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Назва книги є обов'язковою");
        }

        book.setTitle(normalizedTitle);
        book.setAuthor(limitLength(emptyToNull(author), 255));
        book.setDescription(emptyToNull(description));
        book.setGenre(limitLength(emptyToNull(genre), 255));
        book.setPublishYear(parsePublishYear(publishYear));
        book.setAccessLevel(normalizeAccessLevel(accessLevel));

        updateCover(book, coverFile, deleteCover);
        updateBookFile(book, bookFile, deleteBookFile);

        if (isCoverMissing(book.getCoverPath())) {
            book.setCoverPath(NO_COVER_PATH);
        }

        bookRepository.save(book);

        return "redirect:/books/" + id;
    }

    private void updateCover(Book book, MultipartFile coverFile, String deleteCover) throws IOException {
        Path uploadDir = Paths.get(COVER_UPLOAD_DIR);

        if (!Files.exists(uploadDir)) {
            Files.createDirectories(uploadDir);
        }

        if ("true".equals(deleteCover)) {
            deleteOldCoverFile(book.getCoverPath());
            book.setCoverPath(NO_COVER_PATH);
            return;
        }

        if (coverFile != null && !coverFile.isEmpty()) {
            String contentType = coverFile.getContentType();
            String originalFilename = StringUtils.cleanPath(
                    coverFile.getOriginalFilename() == null ? "" : coverFile.getOriginalFilename()
            );

            boolean isImage = contentType != null && contentType.toLowerCase().startsWith("image/");

            if (!isImage) {
                throw new IllegalArgumentException("Можна завантажувати лише зображення");
            }

            deleteOldCoverFile(book.getCoverPath());

            if (originalFilename.isBlank()) {
                originalFilename = "cover_" + book.getBookId() + ".jpg";
            }

            if (NO_COVER_FILENAME.equalsIgnoreCase(originalFilename)) {
                String extension = getFileExtension(originalFilename);
                originalFilename = "cover_" + book.getBookId() + "_" + System.currentTimeMillis() + extension;
            }

            String extension = getFileExtension(originalFilename);

            if (extension.isBlank()) {
                extension = ".jpg";
            }

            String fileName = UUID.randomUUID() + "_cover" + extension;
            Path filePath = uploadDir.resolve(fileName);

            saveResizedCover(coverFile, filePath);

            book.setCoverPath("/uploads/covers/" + fileName);
        } else if (book.getCoverPath() == null || book.getCoverPath().isEmpty()) {
            book.setCoverPath(NO_COVER_PATH);
        }
    }

    private void updateBookFile(Book book, MultipartFile bookFile, String deleteBookFile) throws IOException {
        Path uploadDir = Paths.get(BOOK_FILE_UPLOAD_DIR);

        if (!Files.exists(uploadDir)) {
            Files.createDirectories(uploadDir);
        }

        if ("true".equals(deleteBookFile)) {
            deleteOldBookFile(book.getFilePath());
            book.setFilePath(null);
            return;
        }

        if (bookFile != null && !bookFile.isEmpty()) {
            String contentType = bookFile.getContentType();
            String originalFilename = StringUtils.cleanPath(
                    bookFile.getOriginalFilename() == null ? "" : bookFile.getOriginalFilename()
            );

            boolean isPdf = "application/pdf".equalsIgnoreCase(contentType)
                    || originalFilename.toLowerCase().endsWith(".pdf");

            if (!isPdf) {
                throw new IllegalArgumentException("Можна завантажувати лише PDF-файли");
            }

            deleteOldBookFile(book.getFilePath());

            if (originalFilename.isBlank()) {
                originalFilename = "book_" + book.getBookId() + ".pdf";
            }

            String fileName = UUID.randomUUID() + "_" + originalFilename;
            Path filePath = uploadDir.resolve(fileName);

            Files.copy(bookFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            book.setFilePath("/uploads/books/" + fileName);
        }
    }

    private void saveResizedCover(MultipartFile file, Path filePath) throws IOException {
        Thumbnails.of(file.getInputStream())
                .size(500, 750)
                .outputQuality(0.85)
                .toFile(filePath.toFile());
    }

    private void deleteOldCoverFile(String coverPath) throws IOException {
        if (coverPath != null && !coverPath.isEmpty() && !coverPath.endsWith(NO_COVER_FILENAME)) {
            String filename = Paths.get(coverPath).getFileName().toString();
            Path filePath = Paths.get(COVER_UPLOAD_DIR).resolve(filename);
            Files.deleteIfExists(filePath);
        }
    }

    private void deleteOldBookFile(String bookFilePath) throws IOException {
        if (bookFilePath != null && !bookFilePath.isEmpty()) {
            String filename = Paths.get(bookFilePath).getFileName().toString();
            Path filePath = Paths.get(BOOK_FILE_UPLOAD_DIR).resolve(filename);
            Files.deleteIfExists(filePath);
        }
    }

    private boolean isCoverMissing(String coverPath) {
        if (coverPath == null || coverPath.isBlank()) {
            return true;
        }

        if (coverPath.startsWith("http://") || coverPath.startsWith("https://")) {
            return false;
        }

        String normalizedPath = coverPath.startsWith("/")
                ? coverPath.substring(1)
                : coverPath;

        return !Files.exists(Paths.get(normalizedPath));
    }

    private String normalizeAccessLevel(String accessLevel) {
        if ("SUBSCRIPTION".equalsIgnoreCase(accessLevel)) {
            return "SUBSCRIPTION";
        }

        return "FREE";
    }

    private Integer parsePublishYear(String value) {
        if (value == null || value.trim().isEmpty()) {
            return null;
        }

        try {
            int year = Integer.parseInt(value.trim());

            if (year < 0 || year > 2100) {
                return null;
            }

            return year;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String limitLength(String value, int maxLength) {
        if (value == null) {
            return null;
        }

        String trimmed = value.trim();

        if (trimmed.length() <= maxLength) {
            return trimmed;
        }

        return trimmed.substring(0, maxLength);
    }

    private String emptyToNull(String value) {
        return value == null || value.trim().isEmpty() ? null : value.trim();
    }

    private String getFileExtension(String filename) {
        if (filename == null) {
            return "";
        }

        int dotIdx = filename.lastIndexOf('.');

        if (dotIdx > 0 && dotIdx < filename.length() - 1) {
            return filename.substring(dotIdx);
        }

        return "";
    }
}