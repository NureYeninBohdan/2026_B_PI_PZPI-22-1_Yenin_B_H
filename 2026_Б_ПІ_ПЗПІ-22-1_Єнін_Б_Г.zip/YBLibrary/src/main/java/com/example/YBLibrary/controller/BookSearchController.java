package com.example.YBLibrary.controller;

import com.example.YBLibrary.dto.BookSearchDTO;
import com.example.YBLibrary.model.Book;
import com.example.YBLibrary.repository.BookRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookSearchController {

    private final BookRepository bookRepository;

    private static final String NO_COVER_PATH = "/uploads/covers/No Cover.jpg";

    public BookSearchController(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @GetMapping("/suggestions")
    public ResponseEntity<List<BookSearchDTO>> getBookSuggestions(@RequestParam String query) {
        String normalizedQuery = query == null ? "" : query.trim();

        if (normalizedQuery.length() < 2) {
            return ResponseEntity.ok(List.of());
        }

        List<BookSearchDTO> suggestions = bookRepository
                .findBookSuggestions(normalizedQuery, PageRequest.of(0, 5))
                .stream()
                .map(this::toDto)
                .toList();

        return ResponseEntity.ok(suggestions);
    }

    private BookSearchDTO toDto(Book book) {
        String coverPath = book.getCoverPath();

        if (coverPath == null || coverPath.isBlank()) {
            coverPath = NO_COVER_PATH;
        }

        return new BookSearchDTO(
                book.getBookId(),
                book.getTitle(),
                book.getAuthor(),
                coverPath
        );
    }
}