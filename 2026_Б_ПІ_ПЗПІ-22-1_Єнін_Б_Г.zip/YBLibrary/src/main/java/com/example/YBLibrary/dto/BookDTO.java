package com.example.YBLibrary.dto;

public class BookDTO {
    private String title;
    private String author;
    private String coverPath;
    private String bookDumpId;
    private String description;
    private Double averageRating;
    private String key;
    private Long popularity;

    private String genre;
    private Integer publishYear;
    private String filePath;
    private String accessLevel;

    public BookDTO() {
    }

    public BookDTO(String title, String author, String coverPath, String bookDumpId,
                   String description, Double averageRating, String key, Long popularity,
                   String genre, Integer publishYear, String filePath, String accessLevel) {
        this.title = title;
        this.author = author;
        this.coverPath = coverPath;
        this.bookDumpId = bookDumpId;
        this.description = description;
        this.averageRating = averageRating;
        this.key = key;
        this.popularity = popularity;
        this.genre = genre;
        this.publishYear = publishYear;
        this.filePath = filePath;
        this.accessLevel = accessLevel;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getCoverPath() {
        return coverPath;
    }

    public String getBookDumpId() {
        return bookDumpId;
    }

    public String getDescription() {
        return description;
    }

    public Double getAverageRating() {
        return averageRating;
    }

    public String getKey() {
        return key;
    }

    public Long getPopularity() {
        return popularity;
    }

    public String getGenre() {
        return genre;
    }

    public Integer getPublishYear() {
        return publishYear;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getAccessLevel() {
        return accessLevel;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setCoverPath(String coverPath) {
        this.coverPath = coverPath;
    }

    public void setBookDumpId(String bookDumpId) {
        this.bookDumpId = bookDumpId;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setAverageRating(Double averageRating) {
        this.averageRating = averageRating;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setPopularity(Long popularity) {
        this.popularity = popularity;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setPublishYear(Integer publishYear) {
        this.publishYear = publishYear;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public void setAccessLevel(String accessLevel) {
        this.accessLevel = accessLevel;
    }
}