package com.example.YBLibrary.dto;

public class LiqPayCheckoutForm {

    private String checkoutUrl;
    private String data;
    private String signature;

    public LiqPayCheckoutForm(String checkoutUrl, String data, String signature) {
        this.checkoutUrl = checkoutUrl;
        this.data = data;
        this.signature = signature;
    }

    public String getCheckoutUrl() {
        return checkoutUrl;
    }

    public String getData() {
        return data;
    }

    public String getSignature() {
        return signature;
    }
}