package com.example.YBLibrary.repository;

import com.example.YBLibrary.model.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    List<Comment> findByBookIdOrderBySentAtDesc(Long bookId);
}
