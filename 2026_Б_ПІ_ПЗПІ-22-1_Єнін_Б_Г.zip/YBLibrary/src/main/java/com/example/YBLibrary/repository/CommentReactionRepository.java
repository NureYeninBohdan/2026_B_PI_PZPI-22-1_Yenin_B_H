package com.example.YBLibrary.repository;

import com.example.YBLibrary.model.CommentReaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CommentReactionRepository extends JpaRepository<CommentReaction, Long> {

    Optional<CommentReaction> findByCommentIdAndUserId(Long commentId, Long userId);

    long countByCommentIdAndReactionType(Long commentId, String reactionType);

    void deleteByCommentId(Long commentId);
}