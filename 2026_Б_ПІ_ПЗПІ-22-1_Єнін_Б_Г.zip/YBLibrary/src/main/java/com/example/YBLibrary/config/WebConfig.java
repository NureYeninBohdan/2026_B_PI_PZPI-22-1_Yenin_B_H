package com.example.YBLibrary.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.CacheControl;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private static final int IMAGE_CACHE_DAYS = 30;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        Path avatarUploadDir = Paths.get("uploads/avatars").toAbsolutePath().normalize();
        Path coverUploadDir = Paths.get("uploads/covers").toAbsolutePath().normalize();

        registry.addResourceHandler("/uploads/avatars/**")
                .addResourceLocations(avatarUploadDir.toUri().toString())
                .setCacheControl(
                        CacheControl.maxAge(IMAGE_CACHE_DAYS, TimeUnit.DAYS)
                                .cachePublic()
                );

        registry.addResourceHandler("/uploads/covers/**")
                .addResourceLocations(coverUploadDir.toUri().toString())
                .setCacheControl(
                        CacheControl.maxAge(IMAGE_CACHE_DAYS, TimeUnit.DAYS)
                                .cachePublic()
                );
    }
}