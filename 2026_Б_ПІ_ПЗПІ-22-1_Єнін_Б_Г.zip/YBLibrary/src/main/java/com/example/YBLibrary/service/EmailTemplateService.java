package com.example.YBLibrary.service;

import org.springframework.stereotype.Service;

@Service
public class EmailTemplateService {

    public String buildActionEmail(String title,
                                   String greeting,
                                   String message,
                                   String buttonText,
                                   String buttonUrl,
                                   String secondaryMessage) {
        String safeTitle = escapeHtml(title);
        String safeGreeting = escapeHtml(greeting);
        String safeMessage = escapeHtml(message);
        String safeButtonText = escapeHtml(buttonText);
        String safeButtonUrl = escapeHtml(buttonUrl);
        String safeSecondaryMessage = escapeHtml(secondaryMessage);

        return """
                <!DOCTYPE html>
                <html lang="uk">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>%s</title>
                </head>
                <body style="margin:0; padding:0; background-color:#f3f4f6; font-family:Arial, Helvetica, sans-serif; color:#1f2937;">
                    <table width="100%%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#f3f4f6; padding:24px 12px;">
                        <tr>
                            <td align="center">
                                <table width="100%%" cellpadding="0" cellspacing="0" role="presentation" style="max-width:560px; background:#ffffff; border-radius:14px; overflow:hidden; box-shadow:0 8px 20px rgba(0,0,0,0.08);">
                                    
                                    <tr>
                                        <td style="background:linear-gradient(135deg,#1d4ed8,#60a5fa); padding:26px 28px; text-align:center;">
                                            <div style="font-size:26px; font-weight:800; color:#ffffff; letter-spacing:-0.3px;">
                                                YBLibrary
                                            </div>
                                            <div style="margin-top:6px; font-size:14px; color:#dbeafe;">
                                                Онлайн-бібліотека для читання та списків книг
                                            </div>
                                        </td>
                                    </tr>
                
                                    <tr>
                                        <td style="padding:30px 28px 10px 28px;">
                                            <h1 style="margin:0 0 14px 0; font-size:24px; line-height:1.25; color:#1e3a8a;">
                                                %s
                                            </h1>
                
                                            <p style="margin:0 0 16px 0; font-size:16px; line-height:1.6; color:#374151;">
                                                %s
                                            </p>
                
                                            <p style="margin:0 0 24px 0; font-size:15px; line-height:1.6; color:#4b5563;">
                                                %s
                                            </p>
                
                                            <table cellpadding="0" cellspacing="0" role="presentation" style="margin:0 auto 24px auto;">
                                                <tr>
                                                    <td align="center" style="border-radius:10px; background-color:#2563eb;">
                                                        <a href="%s"
                                                           style="display:inline-block; padding:13px 24px; font-size:15px; font-weight:700; color:#ffffff; text-decoration:none; border-radius:10px;">
                                                            %s
                                                        </a>
                                                    </td>
                                                </tr>
                                            </table>
                
                                            <p style="margin:0 0 18px 0; font-size:14px; line-height:1.6; color:#6b7280;">
                                                %s
                                            </p>
                
                                       
                                        </td>
                                    </tr>
                
                                    <tr>
                                        <td style="padding:22px 28px 26px 28px; text-align:center; border-top:1px solid #e5e7eb;">
                                            <p style="margin:0; font-size:12px; line-height:1.5; color:#9ca3af;">
                                                Ви отримали цей лист, тому що була виконана дія на сайті YBLibrary.
                                                Якщо це були не ви, просто проігноруйте цей лист.
                                            </p>
                                        </td>
                                    </tr>
                
                                </table>
                            </td>
                        </tr>
                    </table>
                </body>
                </html>
                """.formatted(
                safeTitle,
                safeTitle,
                safeGreeting,
                safeMessage,
                safeButtonUrl,
                safeButtonText,
                safeSecondaryMessage,
                safeButtonUrl,
                safeButtonUrl
        );
    }

    public String buildPlainTextActionEmail(String greeting,
                                            String message,
                                            String buttonUrl,
                                            String secondaryMessage) {
        return """
                %s

                %s

                Посилання:
                %s

                %s
                """.formatted(
                greeting == null ? "" : greeting,
                message == null ? "" : message,
                buttonUrl == null ? "" : buttonUrl,
                secondaryMessage == null ? "" : secondaryMessage
        );
    }

    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }

        return value
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#039;");
    }
}