package com.example.YBLibrary.model;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "subscriptions")
public class Subscription {

    public static final String STATUS_ACTIVE = "ACTIVE";
    public static final String STATUS_CANCELLED = "CANCELLED";
    public static final String STATUS_EXPIRED = "EXPIRED";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "subscription_id")
    private Long subscriptionId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "is_active", nullable = false)
    private Boolean active = false;

    @Column(name = "plan_code", nullable = false, length = 50)
    private String planCode;

    @Column(name = "plan_title", nullable = false, length = 100)
    private String planTitle;

    @Column(name = "started_at", nullable = false)
    private LocalDateTime startedAt;

    @Column(name = "end_at")
    private LocalDateTime endAt;

    @Column(name = "auto_renew", nullable = false)
    private Boolean autoRenew = false;

    @Column(name = "cancelled_at")
    private LocalDateTime cancelledAt;

    @Column(name = "liqpay_subscription_order_id")
    private String liqpaySubscriptionOrderId;


    @Column(name = "subscription_status", nullable = false, length = 30)
    private String subscriptionStatus = STATUS_ACTIVE;

    @PrePersist
    protected void onCreate() {
        if (startedAt == null) {
            startedAt = LocalDateTime.now();
        }

        if (active == null) {
            active = false;
        }

        if (autoRenew == null) {
            autoRenew = false;
        }

        if (subscriptionStatus == null || subscriptionStatus.isBlank()) {
            subscriptionStatus = STATUS_ACTIVE;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        if (active == null) {
            active = false;
        }

        if (autoRenew == null) {
            autoRenew = false;
        }

        if (subscriptionStatus == null || subscriptionStatus.isBlank()) {
            subscriptionStatus = STATUS_ACTIVE;
        }
    }

    public boolean isActuallyActive() {
        return Boolean.TRUE.equals(active)
                && endAt != null
                && endAt.isAfter(LocalDateTime.now())
                && (STATUS_ACTIVE.equals(subscriptionStatus) || STATUS_CANCELLED.equals(subscriptionStatus));
    }

    public boolean isAutoRenewEnabled() {
        return Boolean.TRUE.equals(autoRenew);
    }

    public void activateForMonths(int months,
                                  String planCode,
                                  String planTitle,
                                  String liqpaySubscriptionOrderId) {
        LocalDate baseDate;

        if (isActuallyActive()) {
            baseDate = endAt.toLocalDate().minusDays(1);
        } else {
            baseDate = LocalDate.now();
            this.startedAt = LocalDateTime.now();
        }

        this.active = true;
        this.planCode = planCode;
        this.planTitle = planTitle;

        this.endAt = baseDate
                .plusMonths(months)
                .plusDays(1)
                .atStartOfDay();

        this.autoRenew = true;
        this.cancelledAt = null;
        this.subscriptionStatus = STATUS_ACTIVE;
        this.liqpaySubscriptionOrderId = liqpaySubscriptionOrderId;
    }

    public void cancelAutoRenew() {
        this.autoRenew = false;
        this.cancelledAt = LocalDateTime.now();

        if (isActuallyActive()) {
            this.subscriptionStatus = STATUS_CANCELLED;
        }
    }


    public void markExpired() {
        this.active = false;
        this.autoRenew = false;
        this.subscriptionStatus = STATUS_EXPIRED;
    }

    public Long getSubscriptionId() {
        return subscriptionId;
    }

    public void setSubscriptionId(Long subscriptionId) {
        this.subscriptionId = subscriptionId;
    }

    public Long getId() {
        return subscriptionId;
    }

    public void setId(Long id) {
        this.subscriptionId = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Boolean isActive() {
        return active;
    }

    public String getPlanCode() {
        return planCode;
    }

    public void setPlanCode(String planCode) {
        this.planCode = planCode;
    }

    public String getPlanTitle() {
        return planTitle;
    }

    public void setPlanTitle(String planTitle) {
        this.planTitle = planTitle;
    }

    public LocalDateTime getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(LocalDateTime startedAt) {
        this.startedAt = startedAt;
    }

    public LocalDateTime getEndAt() {
        return endAt;
    }

    public void setEndAt(LocalDateTime endAt) {
        this.endAt = endAt;
    }

    public Boolean getAutoRenew() {
        return autoRenew;
    }

    public void setAutoRenew(Boolean autoRenew) {
        this.autoRenew = autoRenew;
    }

    public LocalDateTime getCancelledAt() {
        return cancelledAt;
    }

    public void setCancelledAt(LocalDateTime cancelledAt) {
        this.cancelledAt = cancelledAt;
    }

    public String getLiqpaySubscriptionOrderId() {
        return liqpaySubscriptionOrderId;
    }

    public void setLiqpaySubscriptionOrderId(String liqpaySubscriptionOrderId) {
        this.liqpaySubscriptionOrderId = liqpaySubscriptionOrderId;
    }



    public String getSubscriptionStatus() {
        return subscriptionStatus;
    }

    public void setSubscriptionStatus(String subscriptionStatus) {
        this.subscriptionStatus = subscriptionStatus;
    }
}