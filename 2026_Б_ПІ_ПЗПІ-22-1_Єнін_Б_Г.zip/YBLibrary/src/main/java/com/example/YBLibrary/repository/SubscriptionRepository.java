package com.example.YBLibrary.repository;

import com.example.YBLibrary.model.Subscription;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {

    Optional<Subscription> findFirstByUserUserIdAndActiveTrueOrderByEndAtDesc(Long userId);

    Optional<Subscription> findFirstByUserUserIdOrderByStartedAtDesc(Long userId);

    List<Subscription> findByUserUserIdOrderByStartedAtDesc(Long userId);
}