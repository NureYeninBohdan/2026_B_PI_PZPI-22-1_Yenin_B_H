package com.example.YBLibrary.controller;

import com.example.YBLibrary.dto.UserSettingsDTO;
import com.example.YBLibrary.model.User;
import com.example.YBLibrary.service.CustomUserDetails;
import com.example.YBLibrary.service.SubscriptionService;
import com.example.YBLibrary.service.UserService;
import com.example.YBLibrary.service.UserService.EmailChangeConfirmationInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Controller
public class SettingsController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private SubscriptionService subscriptionService;

    private static final DateTimeFormatter SUBSCRIPTION_DATE_FORMATTER =
            DateTimeFormatter.ofPattern("dd.MM.yyyy");

    @GetMapping("/settings")
    public String showSettingsPage(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (!isRealAuthenticatedUser(authentication)) {
            return "redirect:/login";
        }

        CustomUserDetails currentUser = (CustomUserDetails) authentication.getPrincipal();

        User user = userService.findByUsername(currentUser.getUsername());

        UserSettingsDTO userSettingsDTO = new UserSettingsDTO();
        userSettingsDTO.setUsername(user.getUsername());
        userSettingsDTO.setEmail(user.getEmail());

        model.addAttribute("userSettingsDTO", userSettingsDTO);

        model.addAttribute("currentEmail", user.getEmail());
        model.addAttribute("maskedCurrentEmail", userService.maskEmail(user.getEmail()));

        model.addAttribute("pendingEmail", user.getPendingEmail());
        model.addAttribute("maskedPendingEmail", userService.maskEmail(user.getPendingEmail()));
        model.addAttribute("emailChangeStage", user.getEmailChangeStage());

        Long userId = user.getUserId();

        boolean hasActiveSubscription = subscriptionService.hasActiveSubscription(userId);

        model.addAttribute("hasActiveSubscription", hasActiveSubscription);
        model.addAttribute("subscriptionEnd", formatSubscriptionEnd(subscriptionService.getSubscriptionEnd(userId)));
        model.addAttribute("currentSubscriptionPlanTitle", getCurrentSubscriptionPlanTitle(userId));
        model.addAttribute("subscriptionAutoRenew", subscriptionService.isAutoRenewEnabled(userId));

        return "settings";
    }

    @PostMapping("/settings")
    public String updateSettings(UserSettingsDTO userSettingsDTO,
                                 RedirectAttributes redirectAttributes) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (!isRealAuthenticatedUser(authentication)) {
            return "redirect:/login";
        }

        boolean passwordChangeRequested = userSettingsDTO.getNewPassword() != null
                && !userSettingsDTO.getNewPassword().isBlank();

        String activeTab = passwordChangeRequested ? "password" : "account";

        CustomUserDetails currentUser = (CustomUserDetails) authentication.getPrincipal();
        Long userId = currentUser.getId();

        User userBeforeUpdate = userService.findById(userId);

        String oldUsername = userBeforeUpdate.getUsername();
        String oldEmail = userBeforeUpdate.getEmail();

        String requestedUsername = normalize(userSettingsDTO.getUsername());
        String requestedEmail = normalize(userSettingsDTO.getEmail());

        boolean emailChangeRequested = requestedEmail != null
                && !requestedEmail.isBlank()
                && !requestedEmail.equalsIgnoreCase(oldEmail);

        if (passwordChangeRequested) {
            if (!userSettingsDTO.getNewPassword().equals(userSettingsDTO.getConfirmNewPassword())) {
                redirectAttributes.addFlashAttribute("errorMessage", "Нові паролі не збігаються");
                redirectAttributes.addFlashAttribute("userSettingsDTO", userSettingsDTO);
                redirectAttributes.addFlashAttribute("activeSettingsTab", activeTab);
                return "redirect:/settings";
            }
        }

        try {
            userService.updateUserSettings(userId, userSettingsDTO);

            if (requestedUsername != null
                    && !requestedUsername.isBlank()
                    && !requestedUsername.equals(oldUsername)) {
                refreshAuthentication(requestedUsername);
            }

            if (emailChangeRequested) {
                redirectAttributes.addFlashAttribute(
                        "successMessage",
                        "Дані акаунту збережено. Для зміни email ми надіслали лист підтвердження на вашу поточну адресу."
                );
            } else {
                redirectAttributes.addFlashAttribute("successMessage", "Налаштування збережено");
            }

            redirectAttributes.addFlashAttribute("activeSettingsTab", activeTab);
        } catch (IllegalArgumentException | IllegalStateException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            redirectAttributes.addFlashAttribute("userSettingsDTO", userSettingsDTO);
            redirectAttributes.addFlashAttribute("activeSettingsTab", activeTab);
        }

        return "redirect:/settings";
    }

    @GetMapping("/settings/email/confirm")
    public String showEmailChangeConfirmation(@RequestParam("token") String token,
                                              Model model) {
        try {
            EmailChangeConfirmationInfo info = userService.getEmailChangeConfirmationInfo(token);

            model.addAttribute("token", token);
            model.addAttribute("stage", info.getStage());

            model.addAttribute("currentEmail", info.getCurrentEmail());
            model.addAttribute("pendingEmail", info.getPendingEmail());

            model.addAttribute("maskedCurrentEmail", info.getMaskedCurrentEmail());
            model.addAttribute("maskedPendingEmail", info.getMaskedPendingEmail());

            if ("CURRENT".equals(info.getStage())) {
                model.addAttribute("title", "Підтвердження поточної адреси");
                model.addAttribute(
                        "message",
                        "Підтвердіть, що ви справді хочете змінити email акаунта. Після цього ми надішлемо лист на нову адресу."
                );
                model.addAttribute("buttonText", "Підтвердити поточну адресу");
            } else {
                model.addAttribute("title", "Підтвердження нової адреси");
                model.addAttribute(
                        "message",
                        "Підтвердіть нову email-адресу, щоб завершити зміну email акаунта."
                );
                model.addAttribute("buttonText", "Підтвердити нову адресу");
            }
        } catch (IllegalArgumentException | IllegalStateException e) {
            model.addAttribute("errorMessage", e.getMessage());
        }

        return "email-change-confirm";
    }

    @PostMapping("/settings/email/confirm")
    public String confirmEmailChange(@RequestParam("token") String token,
                                     Model model) {
        try {
            String result = userService.confirmEmailChange(token);

            if ("CURRENT_CONFIRMED".equals(result)) {
                model.addAttribute(
                        "successMessage",
                        "Поточну адресу підтверджено. Ми надіслали другий лист на нову email-адресу."
                );
            } else if ("EMAIL_CHANGED".equals(result)) {
                model.addAttribute(
                        "successMessage",
                        "Email акаунта успішно змінено. На стару адресу надіслано повідомлення про зміну."
                );
            } else {
                model.addAttribute("successMessage", "Підтвердження email виконано.");
            }
        } catch (IllegalArgumentException | IllegalStateException e) {
            model.addAttribute("errorMessage", e.getMessage());
        }

        return "email-change-confirm";
    }

    @PostMapping("/settings/subscription/cancel-renewal")
    public String cancelSubscriptionRenewal(RedirectAttributes redirectAttributes) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (!isRealAuthenticatedUser(authentication)) {
            return "redirect:/login";
        }

        Long userId = ((CustomUserDetails) authentication.getPrincipal()).getId();

        try {
            subscriptionService.cancelAutoRenew(userId);

            redirectAttributes.addFlashAttribute(
                    "successMessage",
                    "Автопоновлення підписки скасовано. Доступ залишиться активним до кінця оплаченого періоду."
            );
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }

        redirectAttributes.addFlashAttribute("activeSettingsTab", "subscription");

        return "redirect:/settings#subscription-management";
    }



    private void refreshAuthentication(String username) {
        UserDetails userDetails = userDetailsService.loadUserByUsername(username);

        UsernamePasswordAuthenticationToken newAuth =
                new UsernamePasswordAuthenticationToken(
                        userDetails,
                        userDetails.getPassword(),
                        userDetails.getAuthorities()
                );

        SecurityContextHolder.getContext().setAuthentication(newAuth);
    }

    private boolean isRealAuthenticatedUser(Authentication authentication) {
        return authentication != null
                && authentication.isAuthenticated()
                && authentication.getPrincipal() instanceof CustomUserDetails;
    }

    private String formatSubscriptionEnd(LocalDateTime subscriptionEnd) {
        if (subscriptionEnd == null) {
            return null;
        }

        return subscriptionEnd.format(SUBSCRIPTION_DATE_FORMATTER);
    }

    private String getCurrentSubscriptionPlanTitle(Long userId) {
        String title = subscriptionService.getSubscriptionPlanTitle(userId);

        if (title == null || title.isBlank()) {
            return "Активна підписка";
        }

        return title;
    }

    private String normalize(String value) {
        return value == null ? null : value.trim();
    }
}