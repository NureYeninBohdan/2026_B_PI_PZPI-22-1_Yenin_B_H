package com.example.YBLibrary.controller;

import com.example.YBLibrary.service.BookJsonImportService;
import com.example.YBLibrary.service.CustomUserDetails;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Controller
public class AdminBookImportController {

    private static final DateTimeFormatter FILE_DATE_FORMATTER =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

    private final BookJsonImportService bookJsonImportService;

    @Value("${books.import.upload-dir:uploads/imports}")
    private String importUploadDir;

    public AdminBookImportController(BookJsonImportService bookJsonImportService) {
        this.bookJsonImportService = bookJsonImportService;
    }

    @PostMapping("/admin/books/import-json")
    public ResponseEntity<String> importBooksFromJson(@RequestParam("file") MultipartFile file,
                                                      Authentication authentication) {
        if (bookJsonImportService.isImportRunning()) {
            return ResponseEntity.status(409).body("Імпорт уже виконується. Дочекайтеся завершення поточного імпорту.");
        }

        if (file == null || file.isEmpty()) {
            return ResponseEntity.badRequest().body("Файл не вибрано.");
        }

        String originalFileName = file.getOriginalFilename();

        if (originalFileName == null || originalFileName.isBlank()) {
            originalFileName = "books.json";
        }

        if (!originalFileName.toLowerCase().endsWith(".json")) {
            return ResponseEntity.badRequest().body("Можна імпортувати лише JSON-файли.");
        }

        try {
            Path uploadDir = Path.of(importUploadDir).toAbsolutePath().normalize();
            Files.createDirectories(uploadDir);

            String safeFileName = buildSafeFileName(originalFileName);
            Path savedFile = uploadDir.resolve(safeFileName).normalize();

            if (!savedFile.startsWith(uploadDir)) {
                return ResponseEntity.badRequest().body("Некоректна назва файлу.");
            }

            file.transferTo(savedFile.toFile());

            String startedBy = resolveUsername(authentication);

            bookJsonImportService.importBooksFromJsonFile(savedFile, originalFileName, startedBy);

            return ResponseEntity.ok("Імпорт запущено у фоні. Прогрес буде відображатися в консолі сервера.");
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body("Не вдалося запустити імпорт: " + e.getMessage());
        }
    }

    private String buildSafeFileName(String originalFileName) {
        String extension = ".json";

        String baseName = originalFileName;

        int dotIndex = originalFileName.lastIndexOf('.');

        if (dotIndex > 0) {
            baseName = originalFileName.substring(0, dotIndex);
        }

        baseName = baseName
                .replaceAll("[^a-zA-Z0-9а-яА-ЯіїєґІЇЄҐ._-]+", "_")
                .replaceAll("_+", "_");

        if (baseName.isBlank()) {
            baseName = "books";
        }

        return baseName
                + "_"
                + LocalDateTime.now().format(FILE_DATE_FORMATTER)
                + extension;
    }

    private String resolveUsername(Authentication authentication) {
        if (authentication != null && authentication.getPrincipal() instanceof CustomUserDetails principal) {
            return principal.getUsername();
        }

        return "unknown";
    }
}