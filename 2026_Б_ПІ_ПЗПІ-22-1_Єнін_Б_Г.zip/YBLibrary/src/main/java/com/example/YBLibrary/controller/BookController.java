package com.example.YBLibrary.controller;

import com.example.YBLibrary.model.Book;
import com.example.YBLibrary.repository.BookRepository;
import com.example.YBLibrary.service.BookFilterService;
import com.example.YBLibrary.service.CommentService;
import com.example.YBLibrary.service.CustomUserDetails;
import com.example.YBLibrary.service.RatingService;
import com.example.YBLibrary.service.ReadingStatusService;
import com.example.YBLibrary.service.SubscriptionService;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;

@Controller
public class BookController {

    private final BookFilterService bookFilterService;
    private final ReadingStatusService readingStatusService;
    private final RatingService ratingService;
    private final BookRepository bookRepository;
    private final CommentService commentService;
    private final SubscriptionService subscriptionService;

    private static final String NO_COVER_PATH = "/uploads/covers/No Cover.jpg";

    public BookController(BookFilterService bookFilterService,
                          ReadingStatusService readingStatusService,
                          RatingService ratingService,
                          BookRepository bookRepository,
                          CommentService commentService,
                          SubscriptionService subscriptionService) {
        this.bookRepository = bookRepository;
        this.bookFilterService = bookFilterService;
        this.readingStatusService = readingStatusService;
        this.ratingService = ratingService;
        this.commentService = commentService;
        this.subscriptionService = subscriptionService;
    }

    @GetMapping("/")
    public String showHomePage(@AuthenticationPrincipal CustomUserDetails currentUser,
                               @RequestParam(value = "search", required = false) String search,
                               @RequestParam(value = "sort", required = false) String sort,
                               @RequestParam(value = "selectedGenres", required = false) List<String> selectedGenres,
                               @RequestParam(value = "publishYear", required = false) Integer publishYear,
                               @RequestParam(value = "accessLevels", required = false) List<String> accessLevels,
                               @RequestParam(value = "filtersApplied", required = false, defaultValue = "false") Boolean filtersApplied,
                               @RequestParam(value = "page", defaultValue = "0") int page,
                               @RequestParam(value = "size", defaultValue = "24") int size,
                               Model model) {

        Long userId = currentUser != null ? currentUser.getId() : null;

        List<String> safeSelectedGenres = selectedGenres == null
                ? Collections.emptyList()
                : selectedGenres;

        List<String> safeAccessLevels = accessLevels == null
                ? Collections.emptyList()
                : accessLevels;

        boolean filterWasApplied = Boolean.TRUE.equals(filtersApplied);

        Page<Book> booksPage = bookFilterService.getBooks(
                search,
                sort,
                safeSelectedGenres,
                publishYear,
                safeAccessLevels,
                filterWasApplied,
                userId,
                page,
                size
        );

        booksPage.getContent().forEach(this::prepareBookForView);

        model.addAttribute("books", booksPage.getContent());
        model.addAttribute("page", booksPage);

        model.addAttribute("sort", sort == null ? "" : sort);
        model.addAttribute("search", search == null ? "" : search);

        model.addAttribute("genres", bookFilterService.getAllGenres());
        model.addAttribute("selectedGenres", safeSelectedGenres);

        model.addAttribute("publishYear", publishYear);

        model.addAttribute("accessLevels", safeAccessLevels);
        model.addAttribute("filtersApplied", filterWasApplied);

        return "index";
    }

    @GetMapping("/books/{id}")
    public String showBookDetails(@PathVariable Long id,
                                  @AuthenticationPrincipal CustomUserDetails currentUser,
                                  Model model) {

        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Книга не знайдена"));

        prepareBookForView(book);

        boolean isSubscribed = hasActiveSubscription(currentUser);
        boolean canReadBook = canReadBook(book, isSubscribed);

        model.addAttribute("book", book);
        model.addAttribute("canReadBook", canReadBook);
        model.addAttribute("isSubscriptionBook", "SUBSCRIPTION".equalsIgnoreCase(book.getAccessLevel()));

        Long currentUserId = null;
        boolean isAdmin = false;

        if (currentUser != null) {
            currentUserId = currentUser.getId();
            isAdmin = currentUser.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ADMIN"));

            String status = readingStatusService.findStatusByUserAndBook(currentUserId, id).orElse("Не вибрано");
            model.addAttribute("userStatus", status);

            Integer rating = ratingService.findRatingByUserAndBook(currentUserId, id).orElse(null);
            model.addAttribute("userRating", rating);
        }

        long readCount = readingStatusService.countByBookIdAndStatus(id, "Прочитано");
        long readingCount = readingStatusService.countByBookIdAndStatus(id, "Читаю");
        long plannedCount = readingStatusService.countByBookIdAndStatus(id, "В планах");

        model.addAttribute("readCount", readCount);
        model.addAttribute("readingCount", readingCount);
        model.addAttribute("plannedCount", plannedCount);

        model.addAttribute("comments", commentService.getCommentsForBook(id, currentUserId, isAdmin));

        return "book";
    }

    @GetMapping("/books/{id}/read")
    public String readBook(@PathVariable Long id,
                           @AuthenticationPrincipal CustomUserDetails currentUser,
                           Model model) {

        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Книга не знайдена"));

        prepareBookForView(book);

        boolean isSubscribed = hasActiveSubscription(currentUser);
        boolean canReadBook = canReadBook(book, isSubscribed);

        if (!canReadBook) {
            return "redirect:/subscription";
        }

        if (book.getFilePath() == null || book.getFilePath().isBlank()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Файл книги не додано");
        }

        Path pdfPath = resolveBookFilePath(book.getFilePath());

        if (!Files.exists(pdfPath)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "PDF-файл книги не знайдено");
        }

        model.addAttribute("book", book);

        return "book-reader";
    }

    @GetMapping("/books/{id}/file")
    public ResponseEntity<Resource> getBookFile(@PathVariable Long id,
                                                @AuthenticationPrincipal CustomUserDetails currentUser) {

        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Книга не знайдена"));

        boolean isSubscribed = hasActiveSubscription(currentUser);

        if (!canReadBook(book, isSubscribed)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Недостатньо прав для читання книги");
        }

        if (book.getFilePath() == null || book.getFilePath().isBlank()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Файл книги не додано");
        }

        Path pdfPath = resolveBookFilePath(book.getFilePath());

        if (!Files.exists(pdfPath)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "PDF-файл книги не знайдено");
        }

        Resource resource = new FileSystemResource(pdfPath);

        String contentDisposition = ContentDisposition
                .inline()
                .filename(pdfPath.getFileName().toString(), StandardCharsets.UTF_8)
                .build()
                .toString();

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, contentDisposition)
                .body(resource);
    }

    private void prepareBookForView(Book book) {
        if (isCoverMissing(book.getCoverPath())) {
            book.setCoverPath(NO_COVER_PATH);
        }

        Double avgRating = book.getAverageRating();

        if (avgRating == null) {
            avgRating = 0.0;
        }

        book.setAverageRating(Math.round(avgRating * 100.0) / 100.0);

        if (book.getPopularity() == null) {
            book.setPopularity(0L);
        }

        if (book.getAccessLevel() == null || book.getAccessLevel().isBlank()) {
            book.setAccessLevel("FREE");
        }
    }

    private boolean isCoverMissing(String coverPath) {
        if (coverPath == null || coverPath.isBlank()) {
            return true;
        }

        if (coverPath.startsWith("http://") || coverPath.startsWith("https://")) {
            return false;
        }

        String normalizedPath = coverPath.startsWith("/")
                ? coverPath.substring(1)
                : coverPath;

        return !Files.exists(Paths.get(normalizedPath));
    }

    private Path resolveBookFilePath(String filePath) {
        String normalizedPath = filePath.startsWith("/")
                ? filePath.substring(1)
                : filePath;

        return Paths.get(normalizedPath);
    }

    private boolean canReadBook(Book book, boolean isSubscribed) {
        String accessLevel = book.getAccessLevel();

        if (accessLevel == null || accessLevel.isBlank()) {
            return true;
        }

        if ("FREE".equalsIgnoreCase(accessLevel)) {
            return true;
        }

        return "SUBSCRIPTION".equalsIgnoreCase(accessLevel) && isSubscribed;
    }

    private boolean hasActiveSubscription(CustomUserDetails currentUser) {
        return currentUser != null
                && subscriptionService.hasActiveSubscription(currentUser.getId());
    }
}