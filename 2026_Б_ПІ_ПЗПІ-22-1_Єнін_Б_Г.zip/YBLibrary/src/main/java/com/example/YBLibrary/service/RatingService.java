package com.example.YBLibrary.service;

import com.example.YBLibrary.model.Rating;
import com.example.YBLibrary.model.Book;
import com.example.YBLibrary.repository.RatingRepository;
import com.example.YBLibrary.repository.BookRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.Map;
import java.util.List;
import java.util.Set;

@Service
public class RatingService {

    private final RatingRepository ratingRepository;
    private final BookRepository bookRepository;

    public RatingService(RatingRepository ratingRepository, BookRepository bookRepository) {
        this.ratingRepository = ratingRepository;
        this.bookRepository = bookRepository;
    }

    @Transactional
    public void setUserRating(Long userId, Long bookId, int value) {
        if (value < 1 || value > 5) throw new IllegalArgumentException("Rating must be 1..5");

        Rating rating = ratingRepository.findByUserIdAndBookId(userId, bookId)
                .orElseGet(() -> {
                    Rating r = new Rating();
                    r.setUserId(userId);
                    r.setBookId(bookId);
                    return r;
                });

        rating.setRating(value);
        rating.setRatedAt(LocalDateTime.now());
        ratingRepository.save(rating);

        updateAverageRating(bookId);
    }

    @Transactional
    public void removeUserRating(Long userId, Long bookId) {
        ratingRepository.findByUserIdAndBookId(userId, bookId).ifPresent(ratingRepository::delete);
        updateAverageRating(bookId);
    }

    private void updateAverageRating(Long bookId) {
        double avg = calculateAverageRating(bookId);

        double avgRounded = Math.round(avg * 100.0) / 100.0;

        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new IllegalArgumentException("Book not found: " + bookId));

        book.setAverageRating(avgRounded);
        bookRepository.save(book);
    }

    public Optional<Integer> findRatingByUserAndBook(Long userId, Long bookId) {
        return ratingRepository.findByUserIdAndBookId(userId, bookId)
                .map(Rating::getRating);
    }

    public Map<Long, Integer> findRatingsByUser(Long userId) {
        List<Rating> ratings = ratingRepository.findAllByUserId(userId);
        return ratings.stream()
                .collect(Collectors.toMap(Rating::getBookId, Rating::getRating));
    }


    public double calculateAverageRating(Long bookId) {
        return ratingRepository.findByBookId(bookId).stream()
                .mapToInt(Rating::getRating)
                .average()
                .orElse(0.0);
    }


    public Set<Long> findUserIdsByBookId(Long bookId) {
        return ratingRepository.findUserIdsByBookId(bookId);
    }
}
