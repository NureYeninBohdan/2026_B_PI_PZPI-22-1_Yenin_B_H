package com.example.YBLibrary.service;

import com.example.YBLibrary.model.Subscription;
import com.example.YBLibrary.model.User;
import com.example.YBLibrary.repository.SubscriptionRepository;
import com.example.YBLibrary.repository.UserRepository;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class SubscriptionService {

    private final UserRepository userRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final LiqPayService liqPayService;

    public SubscriptionService(UserRepository userRepository,
                               SubscriptionRepository subscriptionRepository,
                               LiqPayService liqPayService) {
        this.userRepository = userRepository;
        this.subscriptionRepository = subscriptionRepository;
        this.liqPayService = liqPayService;
    }

    public SubscriptionPlan getPlanByCode(String planCode) {
        String normalizedCode = planCode == null
                ? "MONTHLY"
                : planCode.trim().toUpperCase();

        return switch (normalizedCode) {
            case "YEARLY" -> new SubscriptionPlan(
                    "YEARLY",
                    "Річна підписка",
                    12,
                    new BigDecimal("1249"),
                    "year"
            );

            case "MONTHLY" -> new SubscriptionPlan(
                    "MONTHLY",
                    "Місячна підписка",
                    1,
                    new BigDecimal("149"),
                    "month"
            );

            default -> new SubscriptionPlan(
                    "MONTHLY",
                    "Місячна підписка",
                    1,
                    new BigDecimal("149"),
                    "month"
            );
        };
    }

    @Transactional
    public void activateSubscription(Long userId, SubscriptionPlan plan) {
        activateSubscription(userId, plan, null);
    }

    @Transactional
    public void activateSubscription(Long userId,
                                     SubscriptionPlan plan,
                                     String liqpaySubscriptionOrderId) {
        validateActivationInput(userId, plan);

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Користувача не знайдено"));

        Subscription subscription = getCurrentOrNewSubscription(user);

        subscription.activateForMonths(
                plan.getMonths(),
                plan.getCode(),
                plan.getTitle(),
                liqpaySubscriptionOrderId
        );

        subscriptionRepository.save(subscription);
    }

    @Transactional
    public void activateSubscription(Long userId, int months) {
        SubscriptionPlan plan = months == 12
                ? getPlanByCode("YEARLY")
                : getPlanByCode("MONTHLY");

        activateSubscription(userId, plan);
    }

    @Transactional
    public void activateMonthlySubscription(Long userId) {
        activateSubscription(userId, getPlanByCode("MONTHLY"));
    }

    @Transactional
    public void extendSubscriptionAfterRecurringPayment(Long userId,
                                                        SubscriptionPlan plan,
                                                        String liqpaySubscriptionOrderId) {
        validateActivationInput(userId, plan);

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Користувача не знайдено"));

        Subscription subscription = getCurrentOrNewSubscription(user);

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime currentEnd = subscription.getEndAt();
        LocalDateTime baseEnd = currentEnd != null && currentEnd.isAfter(now)
                ? currentEnd
                : now;

        subscription.setActive(true);
        subscription.setPlanCode(plan.getCode());
        subscription.setPlanTitle(plan.getTitle());
        subscription.setEndAt(baseEnd.plusMonths(plan.getMonths()));
        subscription.setAutoRenew(true);
        subscription.setCancelledAt(null);
        subscription.setSubscriptionStatus(Subscription.STATUS_ACTIVE);

        if (subscription.getStartedAt() == null) {
            subscription.setStartedAt(now);
        }

        if (liqpaySubscriptionOrderId != null && !liqpaySubscriptionOrderId.isBlank()) {
            subscription.setLiqpaySubscriptionOrderId(liqpaySubscriptionOrderId.trim());
        }

        subscriptionRepository.save(subscription);
    }

    @Transactional
    public void saveLiqPaySubscriptionOrderId(Long userId,
                                              String liqpaySubscriptionOrderId) {
        if (userId == null) {
            throw new IllegalArgumentException("ID користувача не задано");
        }

        Subscription subscription = findCurrentSubscription(userId)
                .orElseThrow(() -> new IllegalStateException("Підписку не знайдено"));

        if (liqpaySubscriptionOrderId != null && !liqpaySubscriptionOrderId.isBlank()) {
            subscription.setLiqpaySubscriptionOrderId(liqpaySubscriptionOrderId.trim());
        }

        subscriptionRepository.save(subscription);
    }

    @Transactional
    public void cancelAutoRenew(Long userId) {
        Subscription subscription = getRequiredActiveSubscription(userId);

        String liqpayOrderId = subscription.getLiqpaySubscriptionOrderId();

        if (liqpayOrderId == null || liqpayOrderId.isBlank()) {
            throw new IllegalStateException(
                    "Неможливо скасувати автосписання: для цієї підписки не збережено order_id LiqPay"
            );
        }

        JsonNode response;

        try {
            response = liqPayService.unsubscribeSubscription(liqpayOrderId);
        } catch (RuntimeException e) {
            throw new IllegalStateException(
                    "Не вдалося скасувати автосписання в LiqPay. Спробуйте пізніше.",
                    e
            );
        }

        if (!liqPayService.isUnsubscribeSuccessful(response)) {
            throw new IllegalStateException(
                    "LiqPay не підтвердив скасування підписки. Відповідь: " + response.toString()
            );
        }

        subscription.cancelAutoRenew();
        subscriptionRepository.save(subscription);
    }

    @Transactional
    public void markAutoRenewCancelledFromLiqPay(Long userId) {
        Subscription subscription = getCurrentOrLatestSubscription(userId)
                .orElseThrow(() -> new IllegalStateException("Підписку не знайдено"));

        subscription.cancelAutoRenew();
        subscriptionRepository.save(subscription);
    }

    @Transactional
    public void handleRecurringPaymentFailure(Long userId,
                                              String liqpaySubscriptionOrderId,
                                              String status) {
        Subscription subscription = getCurrentOrLatestSubscription(userId)
                .orElseThrow(() -> new IllegalStateException("Підписку не знайдено"));

        subscription.setAutoRenew(false);
        subscription.setCancelledAt(LocalDateTime.now());

        if (liqpaySubscriptionOrderId != null && !liqpaySubscriptionOrderId.isBlank()) {
            subscription.setLiqpaySubscriptionOrderId(liqpaySubscriptionOrderId.trim());
        }

        if (subscription.isActuallyActive()) {
            subscription.setSubscriptionStatus(Subscription.STATUS_CANCELLED);
        } else {
            subscription.setActive(false);
            subscription.setSubscriptionStatus(Subscription.STATUS_EXPIRED);
        }

        subscriptionRepository.save(subscription);
    }

    @Transactional(readOnly = true)
    public boolean hasActiveSubscription(Long userId) {
        if (userId == null) {
            return false;
        }

        return findCurrentSubscription(userId)
                .map(Subscription::isActuallyActive)
                .orElse(false);
    }

    @Transactional(readOnly = true)
    public boolean isAutoRenewEnabled(Long userId) {
        if (userId == null) {
            return false;
        }

        return findCurrentSubscription(userId)
                .filter(Subscription::isActuallyActive)
                .map(Subscription::isAutoRenewEnabled)
                .orElse(false);
    }

    @Transactional(readOnly = true)
    public LocalDateTime getSubscriptionEnd(Long userId) {
        if (userId == null) {
            return null;
        }

        return findCurrentSubscription(userId)
                .filter(Subscription::isActuallyActive)
                .map(Subscription::getEndAt)
                .orElse(null);
    }

    @Transactional(readOnly = true)
    public String getSubscriptionPlanTitle(Long userId) {
        if (userId == null) {
            return null;
        }

        return findCurrentSubscription(userId)
                .filter(Subscription::isActuallyActive)
                .map(Subscription::getPlanTitle)
                .orElse(null);
    }

    @Transactional(readOnly = true)
    public String getSubscriptionPlanCode(Long userId) {
        if (userId == null) {
            return null;
        }

        return findCurrentSubscription(userId)
                .filter(Subscription::isActuallyActive)
                .map(Subscription::getPlanCode)
                .orElse(null);
    }

    @Transactional(readOnly = true)
    public String getLiqpaySubscriptionOrderId(Long userId) {
        if (userId == null) {
            return null;
        }

        return findCurrentSubscription(userId)
                .map(Subscription::getLiqpaySubscriptionOrderId)
                .orElse(null);
    }

    @Transactional(readOnly = true)
    public Optional<Subscription> findCurrentSubscription(Long userId) {
        if (userId == null) {
            return Optional.empty();
        }

        Optional<Subscription> activeSubscription =
                subscriptionRepository.findFirstByUserUserIdAndActiveTrueOrderByEndAtDesc(userId);

        if (activeSubscription.isPresent()) {
            return activeSubscription;
        }

        return subscriptionRepository.findFirstByUserUserIdOrderByStartedAtDesc(userId);
    }

    private Optional<Subscription> getCurrentOrLatestSubscription(Long userId) {
        if (userId == null) {
            return Optional.empty();
        }

        Optional<Subscription> activeSubscription =
                subscriptionRepository.findFirstByUserUserIdAndActiveTrueOrderByEndAtDesc(userId);

        if (activeSubscription.isPresent()) {
            return activeSubscription;
        }

        return subscriptionRepository.findFirstByUserUserIdOrderByStartedAtDesc(userId);
    }

    private Subscription getCurrentOrNewSubscription(User user) {
        Optional<Subscription> existingSubscription =
                subscriptionRepository.findFirstByUserUserIdAndActiveTrueOrderByEndAtDesc(user.getUserId());

        if (existingSubscription.isPresent()) {
            return existingSubscription.get();
        }

        Subscription subscription = new Subscription();
        subscription.setUser(user);
        subscription.setStartedAt(LocalDateTime.now());

        return subscription;
    }

    private Subscription getRequiredActiveSubscription(Long userId) {
        if (userId == null) {
            throw new IllegalArgumentException("ID користувача не задано");
        }

        Subscription subscription = subscriptionRepository
                .findFirstByUserUserIdAndActiveTrueOrderByEndAtDesc(userId)
                .orElseThrow(() -> new IllegalStateException("Активної підписки немає"));

        if (!subscription.isActuallyActive()) {
            throw new IllegalStateException("Активної підписки немає");
        }

        return subscription;
    }

    private void validateActivationInput(Long userId, SubscriptionPlan plan) {
        if (userId == null) {
            throw new IllegalArgumentException("ID користувача не задано");
        }

        if (plan == null) {
            throw new IllegalArgumentException("План підписки не задано");
        }

        if (!isValidSubscriptionMonths(plan.getMonths())) {
            throw new IllegalArgumentException("Некоректний термін підписки: " + plan.getMonths());
        }
    }

    private boolean isValidSubscriptionMonths(int months) {
        return months == 1 || months == 12;
    }

    public static class SubscriptionPlan {

        private final String code;
        private final String title;
        private final int months;
        private final BigDecimal amount;
        private final String liqPayPeriodicity;

        public SubscriptionPlan(String code,
                                String title,
                                int months,
                                BigDecimal amount,
                                String liqPayPeriodicity) {
            this.code = code;
            this.title = title;
            this.months = months;
            this.amount = amount;
            this.liqPayPeriodicity = liqPayPeriodicity;
        }

        public String getCode() {
            return code;
        }

        public String getTitle() {
            return title;
        }

        public int getMonths() {
            return months;
        }

        public BigDecimal getAmount() {
            return amount;
        }

        public String getAmountForLiqPay() {
            return amount.stripTrailingZeros().toPlainString();
        }

        public String getLiqPayPeriodicity() {
            return liqPayPeriodicity;
        }
    }
}