package com.example.YBLibrary.service;

import com.example.YBLibrary.repository.BookRepository;
import com.example.YBLibrary.repository.RatingRepository;
import com.example.YBLibrary.repository.ReadingStatusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BookDeleteService {

    private final BookRepository bookRepository;
    private final RatingRepository ratingRepository;
    private final ReadingStatusRepository readingStatusRepository;

    public BookDeleteService(BookRepository bookRepository,
                             RatingRepository ratingRepository,
                             ReadingStatusRepository readingStatusRepository) {
        this.bookRepository = bookRepository;
        this.ratingRepository = ratingRepository;
        this.readingStatusRepository = readingStatusRepository;
    }

    @Transactional
    public void deleteBookById(Long bookId) {
        ratingRepository.deleteByBookId(bookId);
        readingStatusRepository.deleteByBookId(bookId);

        if (!bookRepository.existsById(bookId)) {
            throw new RuntimeException("Книга не знайдена");
        }
        bookRepository.deleteById(bookId);
    }
}
