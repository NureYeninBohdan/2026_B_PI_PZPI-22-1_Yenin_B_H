package com.example.YBLibrary.controller;

import com.example.YBLibrary.dto.CommentDTO;
import com.example.YBLibrary.dto.CreateCommentRequest;
import com.example.YBLibrary.service.CommentService;
import com.example.YBLibrary.service.CustomUserDetails;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books/{bookId}/comments")
public class CommentController {

    private final CommentService comments;

    public CommentController(CommentService comments) {
        this.comments = comments;
    }

    @GetMapping
    public List<CommentDTO> list(@PathVariable Long bookId, Authentication auth) {
        Long currentUserId = null;
        boolean isAdmin = false;

        if (auth != null && auth.getPrincipal() instanceof CustomUserDetails principal) {
            currentUserId = principal.getId();
            isAdmin = auth.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ADMIN"));
        }

        return comments.getCommentsForBook(bookId, currentUserId, isAdmin);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CommentDTO add(@PathVariable Long bookId,
                          @Valid @RequestBody CreateCommentRequest request,
                          Authentication auth) {
        CustomUserDetails principal = extractPrincipal(auth);
        return comments.addComment(bookId, principal.getId(), request.getComment().trim());
    }

    @DeleteMapping("/{commentId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long bookId,
                       @PathVariable Long commentId,
                       Authentication auth) {
        CustomUserDetails principal = extractPrincipal(auth);
        boolean isAdmin = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ADMIN"));

        comments.deleteComment(commentId, principal.getId(), isAdmin);
    }

    private CustomUserDetails extractPrincipal(Authentication auth) {
        if (auth == null || !(auth.getPrincipal() instanceof CustomUserDetails principal)) {
            throw new AccessDeniedException("Необхідна авторизація");
        }
        return principal;
    }
}
