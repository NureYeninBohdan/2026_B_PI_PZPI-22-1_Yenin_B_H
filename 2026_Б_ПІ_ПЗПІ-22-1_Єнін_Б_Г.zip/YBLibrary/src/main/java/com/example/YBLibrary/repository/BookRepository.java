package com.example.YBLibrary.repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.YBLibrary.model.Book;

public interface BookRepository extends JpaRepository<Book, Long> {


    Optional<Book> findByBookDumpId(String bookDumpId);

    @Query("""
        SELECT b.bookDumpId FROM Book b
        WHERE b.bookDumpId IN :bookDumpIds
    """)
    Set<String> findExistingBookDumpIds(@Param("bookDumpIds") Collection<String> bookDumpIds);


    Page<Book> findAll(Pageable pageable);


    @Query("""
        SELECT b FROM Book b
        WHERE (:query IS NULL
            OR LOWER(b.title) LIKE LOWER(CONCAT('%', :query, '%'))
            OR LOWER(b.author) LIKE LOWER(CONCAT('%', :query, '%')))
          AND (:year IS NULL OR b.publishYear = :year)
    """)
    List<Book> findBooksForFiltering(
            @Param("query") String query,
            @Param("year") Integer year,
            Sort sort
    );



    @Query("""
        SELECT DISTINCT b.genre FROM Book b
        WHERE b.genre IS NOT NULL AND b.genre <> ''
    """)
    List<String> findAllGenreRows();

    default List<String> findAllGenres() {
        Set<String> uniqueGenres = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

        for (String genreRow : findAllGenreRows()) {
            if (genreRow == null || genreRow.isBlank()) {
                continue;
            }

            String[] parts = genreRow.split(",");

            for (String part : parts) {
                String genre = part.trim();

                if (!genre.isEmpty()) {
                    uniqueGenres.add(genre);
                }
            }
        }

        return new ArrayList<>(uniqueGenres);
    }


    @Query("""
        SELECT b FROM Book b
        WHERE LOWER(b.title) LIKE LOWER(CONCAT('%', :query, '%'))
           OR LOWER(b.author) LIKE LOWER(CONCAT('%', :query, '%'))
        ORDER BY
            CASE
                WHEN LOWER(b.title) = LOWER(:query) THEN 0
                WHEN LOWER(b.title) LIKE LOWER(CONCAT(:query, '%')) THEN 1
                WHEN LOWER(b.author) LIKE LOWER(CONCAT(:query, '%')) THEN 2
                ELSE 3
            END,
            b.popularity DESC,
            b.averageRating DESC,
            b.title ASC
    """)
    List<Book> findBookSuggestions(@Param("query") String query, Pageable pageable);
}