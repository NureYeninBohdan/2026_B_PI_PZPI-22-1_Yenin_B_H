package com.example.YBLibrary.dto;

public class CommentReactionDTO {

    private Long commentId;
    private long likeCount;
    private long dislikeCount;
    private String currentUserReaction;

    public CommentReactionDTO() {
    }

    public CommentReactionDTO(Long commentId,
                              long likeCount,
                              long dislikeCount,
                              String currentUserReaction) {
        this.commentId = commentId;
        this.likeCount = likeCount;
        this.dislikeCount = dislikeCount;
        this.currentUserReaction = currentUserReaction;
    }

    public Long getCommentId() {
        return commentId;
    }

    public void setCommentId(Long commentId) {
        this.commentId = commentId;
    }

    public long getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(long likeCount) {
        this.likeCount = likeCount;
    }

    public long getDislikeCount() {
        return dislikeCount;
    }

    public void setDislikeCount(long dislikeCount) {
        this.dislikeCount = dislikeCount;
    }

    public String getCurrentUserReaction() {
        return currentUserReaction;
    }

    public void setCurrentUserReaction(String currentUserReaction) {
        this.currentUserReaction = currentUserReaction;
    }
}