package com.example.YBLibrary.service;

import com.example.YBLibrary.model.Book;
import com.example.YBLibrary.repository.BookRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

@Service
public class BookFilterService {

    private final BookRepository bookRepository;
    private final RatingService ratingService;
    private final ReadingStatusService readingStatusService;

    public BookFilterService(BookRepository bookRepository,
                             RatingService ratingService,
                             ReadingStatusService readingStatusService) {
        this.bookRepository = bookRepository;
        this.ratingService = ratingService;
        this.readingStatusService = readingStatusService;
    }

    public Page<Book> getBooks(String query,
                               String sortType,
                               List<String> selectedGenres,
                               Integer publishYear,
                               List<String> accessLevels,
                               Boolean filtersApplied,
                               Long userId,
                               int page,
                               int size) {

        if (size <= 0) {
            size = 24;
        }

        if (page < 0) {
            page = 0;
        }

        String normalizedQuery = normalizeQuery(query);
        List<String> normalizedGenres = normalizeList(selectedGenres);
        List<String> normalizedAccessLevels = normalizeAccessLevels(accessLevels);

        boolean filterWasApplied = Boolean.TRUE.equals(filtersApplied);

        if (filterWasApplied && normalizedAccessLevels.isEmpty()) {
            Sort sort = buildSort(sortType);
            Pageable pageable = PageRequest.of(page, size, sort);
            return new PageImpl<>(Collections.emptyList(), pageable, 0);
        }

        Sort sort = buildSort(sortType);

        List<Book> baseBooks = bookRepository.findBooksForFiltering(
                normalizedQuery,
                publishYear,
                sort
        );

        List<Book> filteredBooks = baseBooks.stream()
                .filter(book -> matchesAccessLevel(book, normalizedAccessLevels, filterWasApplied))
                .filter(book -> matchesSelectedGenres(book, normalizedGenres))
                .toList();

        return toPage(filteredBooks, page, size, sort);
    }

    public Page<Book> getFreeBooks(String query, String sortType, Long userId, int page, int size) {
        return getBooks(
                query,
                sortType,
                null,
                null,
                List.of("FREE"),
                true,
                userId,
                page,
                size
        );
    }

    public Page<Book> getSubscriptionBooks(String query, String sortType, Long userId, int page, int size) {
        return getBooks(
                query,
                sortType,
                null,
                null,
                List.of("SUBSCRIPTION"),
                true,
                userId,
                page,
                size
        );
    }

    public List<String> getAllGenres() {
        return bookRepository.findAllGenres();
    }

    private Page<Book> toPage(List<Book> books, int page, int size, Sort sort) {
        int total = books == null ? 0 : books.size();

        int from = Math.min(page * size, total);
        int to = Math.min(from + size, total);

        List<Book> content = from < to
                ? books.subList(from, to)
                : Collections.emptyList();

        Pageable pageable = PageRequest.of(page, size, sort);

        return new PageImpl<>(content, pageable, total);
    }

    private String normalizeQuery(String query) {
        if (query == null || query.trim().isEmpty()) {
            return null;
        }

        return query.trim();
    }

    private List<String> normalizeList(List<String> values) {
        if (values == null || values.isEmpty()) {
            return Collections.emptyList();
        }

        return values.stream()
                .filter(value -> value != null && !value.trim().isEmpty())
                .map(String::trim)
                .distinct()
                .toList();
    }

    private List<String> normalizeAccessLevels(List<String> accessLevels) {
        if (accessLevels == null || accessLevels.isEmpty()) {
            return Collections.emptyList();
        }

        return accessLevels.stream()
                .filter(value -> value != null && !value.trim().isEmpty())
                .map(value -> value.trim().toUpperCase(Locale.ROOT))
                .filter(value -> value.equals("FREE") || value.equals("SUBSCRIPTION"))
                .distinct()
                .toList();
    }

    private boolean matchesAccessLevel(Book book,
                                       List<String> selectedAccessLevels,
                                       boolean filterWasApplied) {

        if (!filterWasApplied) {
            return true;
        }

        if (selectedAccessLevels == null || selectedAccessLevels.isEmpty()) {
            return false;
        }

        String bookAccessLevel = book.getAccessLevel();

        if (bookAccessLevel == null || bookAccessLevel.isBlank()) {
            bookAccessLevel = "FREE";
        }

        return selectedAccessLevels.contains(bookAccessLevel.trim().toUpperCase(Locale.ROOT));
    }

    private boolean matchesSelectedGenres(Book book, List<String> selectedGenres) {

        if (selectedGenres == null || selectedGenres.isEmpty()) {
            return true;
        }

        Set<String> bookGenres = splitBookGenres(book.getGenre());

        for (String selectedGenre : selectedGenres) {

            if (selectedGenre == null || selectedGenre.isBlank()) {
                continue;
            }

            String normalizedSelectedGenre =
                    selectedGenre.trim().toLowerCase(Locale.ROOT);

            if (bookGenres.contains(normalizedSelectedGenre)) {
                return true;
            }
        }

        return false;
    }

    private Set<String> splitBookGenres(String genreRow) {

        Set<String> result = new TreeSet<>();

        if (genreRow == null || genreRow.isBlank()) {
            return result;
        }

        String[] parts = genreRow.split(",");

        for (String part : parts) {

            String genre = part.trim().toLowerCase(Locale.ROOT);

            if (!genre.isEmpty()) {
                result.add(genre);
            }
        }

        return result;
    }

    private Sort buildSort(String sortType) {
        return switch (sortType == null ? "" : sortType.toLowerCase(Locale.ROOT)) {
            case "rating" -> Sort.by(Sort.Order.desc("averageRating"));
            case "popularity" -> Sort.by(Sort.Order.desc("popularity"));
            case "year" -> Sort.by(Sort.Order.desc("publishYear"));
            case "genre" -> Sort.by(Sort.Order.asc("genre").ignoreCase())
                    .and(Sort.by(Sort.Order.asc("title").ignoreCase()));
            default -> Sort.by(Sort.Order.asc("title").ignoreCase());
        };
    }
}