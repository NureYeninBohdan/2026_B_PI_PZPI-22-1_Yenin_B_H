package com.example.YBLibrary.controller;

import com.example.YBLibrary.service.CustomUserDetails;
import com.example.YBLibrary.service.SubscriptionService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class GlobalModelAttributes {

    private final SubscriptionService subscriptionService;

    public GlobalModelAttributes(SubscriptionService subscriptionService) {
        this.subscriptionService = subscriptionService;
    }

    @ModelAttribute("isLoggedIn")
    public boolean isLoggedIn(@AuthenticationPrincipal CustomUserDetails currentUser) {
        return currentUser != null;
    }

    @ModelAttribute("isSubscribed")
    public boolean isSubscribed(@AuthenticationPrincipal CustomUserDetails currentUser) {
        return currentUser != null
                && subscriptionService.hasActiveSubscription(currentUser.getId());
    }
}