package com.example.YBLibrary.dto;

public class BookSearchDTO {

    private Long bookId;
    private String title;
    private String author;
    private String coverPath;

    public BookSearchDTO(Long bookId, String title, String author, String coverPath) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.coverPath = coverPath;
    }

    public Long getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getCoverPath() {
        return coverPath;
    }
}