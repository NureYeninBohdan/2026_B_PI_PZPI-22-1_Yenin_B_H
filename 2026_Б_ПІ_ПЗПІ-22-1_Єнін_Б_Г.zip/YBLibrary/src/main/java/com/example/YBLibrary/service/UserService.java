package com.example.YBLibrary.service;

import com.example.YBLibrary.dto.UserSettingsDTO;
import com.example.YBLibrary.model.User;
import com.example.YBLibrary.repository.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {

    private static final String EMAIL_CHANGE_STAGE_CURRENT = "CURRENT";
    private static final String EMAIL_CHANGE_STAGE_NEW = "NEW";

    private static final int EMAIL_CHANGE_TOKEN_TTL_HOURS = 1;
    private static final int PASSWORD_RESET_TOKEN_TTL_HOURS = 1;
    private static final int REGISTRATION_CONFIRMATION_TOKEN_TTL_HOURS = 24;

    private final UserRepository userRepository;
    private final SubscriptionService subscriptionService;
    private final EmailService emailService;
    private final EmailTemplateService emailTemplateService;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Value("${app.base-url}")
    private String appBaseUrl;

    public UserService(UserRepository userRepository,
                       SubscriptionService subscriptionService,
                       EmailService emailService,
                       EmailTemplateService emailTemplateService) {
        this.userRepository = userRepository;
        this.subscriptionService = subscriptionService;
        this.emailService = emailService;
        this.emailTemplateService = emailTemplateService;
    }

    public boolean existsByUsername(String username) {
        return userRepository.findByUsername(username).isPresent();
    }

    public boolean existsByEmail(String email) {
        return userRepository.findByEmail(email).isPresent();
    }

    @Transactional
    public User registerUser(String username, String email, String rawPassword) {
        String normalizedUsername = normalize(username);
        String normalizedEmail = normalize(email);

        if (normalizedUsername == null || normalizedUsername.isBlank()) {
            throw new IllegalArgumentException("Ім'я користувача не може бути порожнім");
        }

        if (normalizedEmail == null || normalizedEmail.isBlank()) {
            throw new IllegalArgumentException("Email не може бути порожнім");
        }

        Optional<User> existingByEmailOpt = userRepository.findByEmail(normalizedEmail);
        Optional<User> existingByUsernameOpt = userRepository.findByUsername(normalizedUsername);

        if (existingByEmailOpt.isPresent()) {
            User existingByEmail = existingByEmailOpt.get();

            if (existingByEmail.isEmailVerified()) {
                throw new IllegalArgumentException("Користувач з таким email вже існує");
            }

            if (existingByUsernameOpt.isPresent()
                    && !Objects.equals(existingByUsernameOpt.get().getUserId(), existingByEmail.getUserId())) {
                throw new IllegalArgumentException("Користувач з таким іменем вже існує");
            }

            return updateUnverifiedRegistration(existingByEmail, normalizedUsername, normalizedEmail, rawPassword);
        }

        if (existingByUsernameOpt.isPresent()) {
            throw new IllegalArgumentException("Користувач з таким іменем вже існує");
        }

        User user = new User();

        user.setUsername(normalizedUsername);
        user.setEmail(normalizedEmail);
        user.setPasswordHash(passwordEncoder.encode(rawPassword));

        ZonedDateTime kyivNow = ZonedDateTime.now(ZoneId.of("Europe/Kiev"));
        user.setCreatedAt(kyivNow);

        user.setRole("USER");
        user.setEmailVerified(false);

        prepareRegistrationConfirmationToken(user);

        User savedUser = userRepository.save(user);

        sendRegistrationConfirmationEmail(savedUser);

        return savedUser;
    }

    private User updateUnverifiedRegistration(User user,
                                              String normalizedUsername,
                                              String normalizedEmail,
                                              String rawPassword) {
        user.setUsername(normalizedUsername);
        user.setEmail(normalizedEmail);
        user.setPasswordHash(passwordEncoder.encode(rawPassword));
        user.setRole("USER");
        user.setEmailVerified(false);
        user.setCreatedAt(ZonedDateTime.now(ZoneId.of("Europe/Kiev")));

        clearRegistrationConfirmationToken(user);
        clearPasswordResetToken(user);
        clearEmailChangeRequest(user);

        prepareRegistrationConfirmationToken(user);

        User savedUser = userRepository.save(user);

        sendRegistrationConfirmationEmail(savedUser);

        return savedUser;
    }

    private void prepareRegistrationConfirmationToken(User user) {
        String token = UUID.randomUUID().toString();

        user.setEmailVerificationToken(token);
        user.setEmailVerificationTokenExpiry(
                LocalDateTime.now().plusHours(REGISTRATION_CONFIRMATION_TOKEN_TTL_HOURS)
        );
    }

    private void sendRegistrationConfirmationEmail(User user) {
        String confirmationLink = buildRegistrationConfirmationLink(user.getEmailVerificationToken());

        String subject = "Підтвердження реєстрації в YBLibrary";
        String title = "Підтвердження реєстрації";
        String greeting = "Вітаємо, " + user.getUsername() + "!";
        String message = "Для завершення реєстрації в YBLibrary підтвердіть вашу email-адресу: "
                + maskEmail(user.getEmail()) + ".";

        String secondaryMessage = "Посилання діє протягом 24 годин. "
                + "Якщо ви не створювали акаунт у YBLibrary, просто проігноруйте цей лист.";

        boolean sent = sendActionEmail(
                user.getEmail(),
                subject,
                title,
                greeting,
                message,
                "Підтвердити реєстрацію",
                confirmationLink,
                secondaryMessage
        );

        if (!sent) {
            throw new IllegalStateException("Не вдалося надіслати лист підтвердження реєстрації");
        }
    }

    @Transactional(readOnly = true)
    public RegistrationConfirmationInfo getRegistrationConfirmationInfo(String token) {
        User user = userRepository.findByEmailVerificationToken(token)
                .orElseThrow(() -> new IllegalArgumentException("Невірний або прострочений токен підтвердження реєстрації"));

        validateRegistrationConfirmationTokenForRead(user);

        return new RegistrationConfirmationInfo(
                user.getUsername(),
                user.getEmail(),
                maskEmail(user.getEmail())
        );
    }

    @Transactional
    public void confirmRegistrationEmail(String token) {
        User user = userRepository.findByEmailVerificationToken(token)
                .orElseThrow(() -> new IllegalArgumentException("Невірний токен підтвердження реєстрації"));

        validateRegistrationConfirmationToken(user);

        user.setEmailVerified(true);
        clearRegistrationConfirmationToken(user);

        userRepository.save(user);
    }

    @Transactional
    public void resendRegistrationConfirmationEmail(String email) {
        String normalizedEmail = normalize(email);

        if (normalizedEmail == null || normalizedEmail.isBlank()) {
            throw new IllegalArgumentException("Email не може бути порожнім");
        }

        User user = userRepository.findByEmail(normalizedEmail)
                .orElseThrow(() -> new IllegalArgumentException("Користувача з таким email не знайдено"));

        if (user.isEmailVerified()) {
            throw new IllegalStateException("Цей акаунт вже підтверджено");
        }

        prepareRegistrationConfirmationToken(user);
        userRepository.save(user);

        sendRegistrationConfirmationEmail(user);
    }

    private void validateRegistrationConfirmationTokenForRead(User user) {
        if (user.isEmailVerified()) {
            throw new IllegalStateException("Цей акаунт вже підтверджено");
        }

        if (user.getEmailVerificationTokenExpiry() == null) {
            throw new IllegalArgumentException("Токен підтвердження реєстрації недійсний");
        }

        if (LocalDateTime.now().isAfter(user.getEmailVerificationTokenExpiry())) {
            throw new IllegalArgumentException("Токен підтвердження реєстрації прострочений");
        }
    }

    private void validateRegistrationConfirmationToken(User user) {
        if (user.isEmailVerified()) {
            clearRegistrationConfirmationToken(user);
            userRepository.save(user);
            throw new IllegalStateException("Цей акаунт вже підтверджено");
        }

        if (user.getEmailVerificationTokenExpiry() == null) {
            clearRegistrationConfirmationToken(user);
            userRepository.save(user);
            throw new IllegalArgumentException("Токен підтвердження реєстрації недійсний");
        }

        if (LocalDateTime.now().isAfter(user.getEmailVerificationTokenExpiry())) {
            clearRegistrationConfirmationToken(user);
            userRepository.save(user);
            throw new IllegalArgumentException("Токен підтвердження реєстрації прострочений");
        }
    }

    private void clearRegistrationConfirmationToken(User user) {
        user.setEmailVerificationToken(null);
        user.setEmailVerificationTokenExpiry(null);
    }

    private void clearPasswordResetToken(User user) {
        user.setResetToken(null);
        user.setResetTokenExpiry(null);
    }

    private String buildRegistrationConfirmationLink(String token) {
        String encodedToken = URLEncoder.encode(token, StandardCharsets.UTF_8);

        return getNormalizedBaseUrl() + "/registration/confirm?token=" + encodedToken;
    }

    public Optional<User> authenticate(String usernameOrEmail, String rawPassword) {
        Optional<User> userOpt = userRepository.findByUsername(usernameOrEmail);

        if (userOpt.isEmpty()) {
            userOpt = userRepository.findByEmail(usernameOrEmail);
        }

        if (userOpt.isPresent()) {
            User user = userOpt.get();

            if (passwordEncoder.matches(rawPassword, user.getPasswordHash())
                    && user.isEmailVerified()) {
                return Optional.of(user);
            }
        }

        return Optional.empty();
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Користувача з таким ім'ям не знайдено"));
    }
    public User findVerifiedByUsername(String username) {
        return userRepository.findByUsernameAndEmailVerifiedTrue(username)
                .orElseThrow(() -> new IllegalArgumentException("Користувача не знайдено"));
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Користувача з таким email не знайдено"));
    }

    public User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Користувача не знайдено"));
    }

    public User save(User user) {
        return userRepository.save(user);
    }


    @Transactional
    public void updateUserSettings(Long userId, UserSettingsDTO dto) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("Користувача не знайдено"));

        updateUsernameIfChanged(user, dto);
        requestEmailChangeIfChanged(user, dto);
        updatePasswordIfRequested(user, dto);

        userRepository.save(user);
    }

    private void updateUsernameIfChanged(User user, UserSettingsDTO dto) {
        String newUsername = normalize(dto.getUsername());

        if (newUsername == null || newUsername.isBlank()) {
            throw new IllegalArgumentException("Ім'я користувача не може бути порожнім");
        }

        if (!newUsername.equals(user.getUsername())) {
            Optional<User> byUsername = userRepository.findByUsername(newUsername);

            if (byUsername.isPresent()) {
                throw new IllegalArgumentException("Користувач з таким іменем вже існує");
            }

            user.setUsername(newUsername);
        }
    }

    private void requestEmailChangeIfChanged(User user, UserSettingsDTO dto) {
        String newEmail = normalize(dto.getEmail());

        if (newEmail == null || newEmail.isBlank()) {
            throw new IllegalArgumentException("Email не може бути порожнім");
        }

        if (newEmail.equalsIgnoreCase(user.getEmail())) {
            return;
        }

        Optional<User> byEmail = userRepository.findByEmail(newEmail);

        if (byEmail.isPresent()) {
            throw new IllegalArgumentException("Користувач з таким email вже існує");
        }

        startEmailChangeRequest(user, newEmail);
    }

    private void startEmailChangeRequest(User user, String newEmail) {
        String token = UUID.randomUUID().toString();

        user.setPendingEmail(newEmail);
        user.setEmailChangeToken(token);
        user.setEmailChangeTokenExpiry(LocalDateTime.now().plusHours(EMAIL_CHANGE_TOKEN_TTL_HOURS));
        user.setEmailChangeStage(EMAIL_CHANGE_STAGE_CURRENT);

        String confirmLink = buildEmailChangeConfirmLink(token);

        String subject = "Підтвердження зміни email";
        String title = "Підтвердження зміни email";
        String greeting = "Запит на зміну email";
        String message = "Ви запросили зміну email для акаунта YBLibrary. "
                + "Поточний email: " + maskEmail(user.getEmail()) + ". "
                + "Новий email: " + maskEmail(newEmail) + ".";

        String secondaryMessage = "Посилання діє протягом 1 години. "
                + "Після відкриття посилання потрібно буде натиснути кнопку підтвердження на сайті. "
                + "Якщо ви не виконували цю дію, просто проігноруйте цей лист.";

        boolean sent = sendActionEmail(
                user.getEmail(),
                subject,
                title,
                greeting,
                message,
                "Підтвердити зміну email",
                confirmLink,
                secondaryMessage
        );

        if (!sent) {
            throw new IllegalStateException("Не вдалося надіслати лист підтвердження на поточну адресу");
        }
    }

    @Transactional(readOnly = true)
    public EmailChangeConfirmationInfo getEmailChangeConfirmationInfo(String token) {
        User user = userRepository.findByEmailChangeToken(token)
                .orElseThrow(() -> new IllegalArgumentException("Невірний або прострочений токен підтвердження"));

        validateEmailChangeTokenForRead(user);

        return new EmailChangeConfirmationInfo(
                user.getEmailChangeStage(),
                user.getEmail(),
                user.getPendingEmail(),
                maskEmail(user.getEmail()),
                maskEmail(user.getPendingEmail())
        );
    }

    @Transactional
    public String confirmEmailChange(String token) {
        User user = userRepository.findByEmailChangeToken(token)
                .orElseThrow(() -> new IllegalArgumentException("Невірний токен підтвердження"));

        validateEmailChangeToken(user);

        String stage = user.getEmailChangeStage();

        if (EMAIL_CHANGE_STAGE_CURRENT.equals(stage)) {
            confirmCurrentEmailAndSendNewEmailConfirmation(user);
            return "CURRENT_CONFIRMED";
        }

        if (EMAIL_CHANGE_STAGE_NEW.equals(stage)) {
            confirmNewEmailAndApplyChange(user);
            return "EMAIL_CHANGED";
        }

        throw new IllegalArgumentException("Некоректний етап підтвердження email");
    }

    private void confirmCurrentEmailAndSendNewEmailConfirmation(User user) {
        String pendingEmail = user.getPendingEmail();

        if (pendingEmail == null || pendingEmail.isBlank()) {
            throw new IllegalArgumentException("Нова email-адреса не задана");
        }

        Optional<User> byEmail = userRepository.findByEmail(pendingEmail);

        if (byEmail.isPresent()) {
            clearEmailChangeRequest(user);
            userRepository.save(user);
            throw new IllegalArgumentException("Користувач з таким email вже існує");
        }

        String newToken = UUID.randomUUID().toString();

        user.setEmailChangeToken(newToken);
        user.setEmailChangeTokenExpiry(LocalDateTime.now().plusHours(EMAIL_CHANGE_TOKEN_TTL_HOURS));
        user.setEmailChangeStage(EMAIL_CHANGE_STAGE_NEW);

        String confirmLink = buildEmailChangeConfirmLink(newToken);

        String subject = "Підтвердження нової email-адреси";
        String title = "Підтвердження нової email-адреси";
        String greeting = "Завершення зміни email";
        String message = "Для завершення зміни email акаунта YBLibrary підтвердіть нову адресу. "
                + "Поточний email акаунта: " + maskEmail(user.getEmail()) + ". "
                + "Нова email-адреса: " + maskEmail(pendingEmail) + ".";

        String secondaryMessage = "Посилання діє протягом 1 години. "
                + "Після відкриття посилання потрібно буде натиснути кнопку підтвердження на сайті. "
                + "Якщо ви не виконували цю дію, просто проігноруйте цей лист.";

        boolean sent = sendActionEmail(
                pendingEmail,
                subject,
                title,
                greeting,
                message,
                "Підтвердити нову адресу",
                confirmLink,
                secondaryMessage
        );

        if (!sent) {
            throw new IllegalStateException("Не вдалося надіслати лист підтвердження на нову адресу");
        }

        userRepository.save(user);
    }

    private void confirmNewEmailAndApplyChange(User user) {
        String oldEmail = user.getEmail();
        String newEmail = user.getPendingEmail();

        if (newEmail == null || newEmail.isBlank()) {
            throw new IllegalArgumentException("Нова email-адреса не задана");
        }

        Optional<User> byEmail = userRepository.findByEmail(newEmail);

        if (byEmail.isPresent()) {
            clearEmailChangeRequest(user);
            userRepository.save(user);
            throw new IllegalArgumentException("Користувач з таким email вже існує");
        }

        user.setEmail(newEmail);
        clearEmailChangeRequest(user);

        userRepository.save(user);

        String subject = "Email акаунта YBLibrary змінено";
        String title = "Email акаунта змінено";
        String greeting = "Повідомлення про зміну email";
        String message = "Email вашого акаунта YBLibrary було успішно змінено. "
                + "Старий email: " + maskEmail(oldEmail) + ". "
                + "Новий email: " + maskEmail(newEmail) + ".";

        String secondaryMessage = "Якщо це були не ви, зверніться до підтримки або спробуйте відновити доступ до акаунта.";

        emailService.sendHtmlEmail(
                oldEmail,
                subject,
                emailTemplateService.buildActionEmail(
                        title,
                        greeting,
                        message,
                        "Перейти на сайт",
                        getNormalizedBaseUrl(),
                        secondaryMessage
                ),
                emailTemplateService.buildPlainTextActionEmail(
                        greeting,
                        message,
                        getNormalizedBaseUrl(),
                        secondaryMessage
                )
        );
    }

    private void validateEmailChangeTokenForRead(User user) {
        if (user.getEmailChangeTokenExpiry() == null) {
            throw new IllegalArgumentException("Токен підтвердження недійсний");
        }

        if (LocalDateTime.now().isAfter(user.getEmailChangeTokenExpiry())) {
            throw new IllegalArgumentException("Токен підтвердження прострочений");
        }

        if (user.getPendingEmail() == null || user.getPendingEmail().isBlank()) {
            throw new IllegalArgumentException("Запит на зміну email недійсний");
        }

        String stage = user.getEmailChangeStage();

        if (!EMAIL_CHANGE_STAGE_CURRENT.equals(stage)
                && !EMAIL_CHANGE_STAGE_NEW.equals(stage)) {
            throw new IllegalArgumentException("Некоректний етап підтвердження email");
        }
    }

    private void validateEmailChangeToken(User user) {
        if (user.getEmailChangeTokenExpiry() == null) {
            clearEmailChangeRequest(user);
            userRepository.save(user);
            throw new IllegalArgumentException("Токен підтвердження недійсний");
        }

        if (LocalDateTime.now().isAfter(user.getEmailChangeTokenExpiry())) {
            clearEmailChangeRequest(user);
            userRepository.save(user);
            throw new IllegalArgumentException("Токен підтвердження прострочений");
        }

        if (user.getPendingEmail() == null || user.getPendingEmail().isBlank()) {
            clearEmailChangeRequest(user);
            userRepository.save(user);
            throw new IllegalArgumentException("Запит на зміну email недійсний");
        }

        String stage = user.getEmailChangeStage();

        if (!EMAIL_CHANGE_STAGE_CURRENT.equals(stage)
                && !EMAIL_CHANGE_STAGE_NEW.equals(stage)) {
            clearEmailChangeRequest(user);
            userRepository.save(user);
            throw new IllegalArgumentException("Некоректний етап підтвердження email");
        }
    }

    private void clearEmailChangeRequest(User user) {
        user.setPendingEmail(null);
        user.setEmailChangeToken(null);
        user.setEmailChangeTokenExpiry(null);
        user.setEmailChangeStage(null);
    }

    private String buildEmailChangeConfirmLink(String token) {
        String encodedToken = URLEncoder.encode(token, StandardCharsets.UTF_8);

        return getNormalizedBaseUrl() + "/settings/email/confirm?token=" + encodedToken;
    }

    private void updatePasswordIfRequested(User user, UserSettingsDTO dto) {
        String currentPassword = dto.getCurrentPassword();
        String newPassword = dto.getNewPassword();
        String confirmNewPassword = dto.getConfirmNewPassword();

        boolean passwordChangeRequested = newPassword != null && !newPassword.isBlank();

        if (!passwordChangeRequested) {
            return;
        }

        if (currentPassword == null || currentPassword.isBlank()) {
            throw new IllegalArgumentException("Введіть поточний пароль");
        }

        if (!passwordEncoder.matches(currentPassword, user.getPasswordHash())) {
            throw new IllegalArgumentException("Поточний пароль введено неправильно");
        }

        if (confirmNewPassword == null || !newPassword.equals(confirmNewPassword)) {
            throw new IllegalArgumentException("Нові паролі не збігаються");
        }

        if (passwordEncoder.matches(newPassword, user.getPasswordHash())) {
            throw new IllegalArgumentException("Новий пароль має відрізнятися від поточного");
        }

        user.setPasswordHash(passwordEncoder.encode(newPassword));
    }

    public String createPasswordResetToken(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Користувача з таким email не знайдено"));

        String token = UUID.randomUUID().toString();

        user.setResetToken(token);
        user.setResetTokenExpiry(LocalDateTime.now().plusHours(PASSWORD_RESET_TOKEN_TTL_HOURS));

        userRepository.save(user);

        return token;
    }

    public boolean isPasswordResetTokenValid(String token) {
        Optional<User> userOpt = userRepository.findByResetToken(token);

        return userOpt.isPresent()
                && userOpt.get().getResetTokenExpiry() != null
                && LocalDateTime.now().isBefore(userOpt.get().getResetTokenExpiry());
    }

    public void updatePassword(String token, String newPassword) {
        Optional<User> userOpt = userRepository.findByResetToken(token);

        if (userOpt.isPresent()) {
            User user = userOpt.get();

            user.setPasswordHash(passwordEncoder.encode(newPassword));
            user.setResetToken(null);
            user.setResetTokenExpiry(null);

            userRepository.save(user);
        }
    }

    public Optional<User> findByResetToken(String token) {
        return userRepository.findByResetToken(token);
    }

    public String maskEmail(String email) {
        String normalizedEmail = normalize(email);

        if (normalizedEmail == null || normalizedEmail.isBlank() || !normalizedEmail.contains("@")) {
            return "невідома адреса";
        }

        String[] parts = normalizedEmail.split("@", 2);

        if (parts.length != 2 || parts[0].isBlank() || parts[1].isBlank()) {
            return "невідома адреса";
        }

        String localPart = parts[0];
        String domainPart = parts[1];

        if (localPart.length() == 1) {
            return "*@" + domainPart;
        }

        if (localPart.length() == 2) {
            return localPart.charAt(0) + "*@" + domainPart;
        }

        String firstTwo = localPart.length() >= 2
                ? localPart.substring(0, 2)
                : localPart.substring(0, 1);

        String last = localPart.substring(localPart.length() - 1);
        int hiddenLength = Math.max(localPart.length() - 3, 0);

        return firstTwo + "*".repeat(hiddenLength) + last + "@" + domainPart;
    }

    private boolean sendActionEmail(String to,
                                    String subject,
                                    String title,
                                    String greeting,
                                    String message,
                                    String buttonText,
                                    String buttonUrl,
                                    String secondaryMessage) {
        String htmlContent = emailTemplateService.buildActionEmail(
                title,
                greeting,
                message,
                buttonText,
                buttonUrl,
                secondaryMessage
        );

        String plainTextFallback = emailTemplateService.buildPlainTextActionEmail(
                greeting,
                message,
                buttonUrl,
                secondaryMessage
        );

        return emailService.sendHtmlEmail(
                to,
                subject,
                htmlContent,
                plainTextFallback
        );
    }

    private String getNormalizedBaseUrl() {
        String normalizedBaseUrl = appBaseUrl == null ? "" : appBaseUrl.trim();

        if (normalizedBaseUrl.endsWith("/")) {
            normalizedBaseUrl = normalizedBaseUrl.substring(0, normalizedBaseUrl.length() - 1);
        }

        return normalizedBaseUrl;
    }

    private String normalize(String value) {
        return value == null ? null : value.trim();
    }

    public static class RegistrationConfirmationInfo {

        private final String username;
        private final String email;
        private final String maskedEmail;

        public RegistrationConfirmationInfo(String username,
                                            String email,
                                            String maskedEmail) {
            this.username = username;
            this.email = email;
            this.maskedEmail = maskedEmail;
        }

        public String getUsername() {
            return username;
        }

        public String getEmail() {
            return email;
        }

        public String getMaskedEmail() {
            return maskedEmail;
        }
    }

    public static class EmailChangeConfirmationInfo {

        private final String stage;
        private final String currentEmail;
        private final String pendingEmail;
        private final String maskedCurrentEmail;
        private final String maskedPendingEmail;

        public EmailChangeConfirmationInfo(String stage,
                                           String currentEmail,
                                           String pendingEmail,
                                           String maskedCurrentEmail,
                                           String maskedPendingEmail) {
            this.stage = stage;
            this.currentEmail = currentEmail;
            this.pendingEmail = pendingEmail;
            this.maskedCurrentEmail = maskedCurrentEmail;
            this.maskedPendingEmail = maskedPendingEmail;
        }

        public String getStage() {
            return stage;
        }

        public String getCurrentEmail() {
            return currentEmail;
        }

        public String getPendingEmail() {
            return pendingEmail;
        }

        public String getMaskedCurrentEmail() {
            return maskedCurrentEmail;
        }

        public String getMaskedPendingEmail() {
            return maskedPendingEmail;
        }
    }
}