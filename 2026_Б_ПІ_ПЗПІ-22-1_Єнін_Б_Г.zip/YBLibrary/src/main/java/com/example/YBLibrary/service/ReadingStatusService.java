package com.example.YBLibrary.service;

import com.example.YBLibrary.model.ReadingStatus;
import com.example.YBLibrary.model.Book;
import com.example.YBLibrary.repository.ReadingStatusRepository;
import com.example.YBLibrary.repository.BookRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.HashSet;


@Service
public class ReadingStatusService {

    private final ReadingStatusRepository readingStatusRepository;
    private final BookRepository bookRepository;
    private final RatingService ratingService;

    public ReadingStatusService(ReadingStatusRepository readingStatusRepository,
                                BookRepository bookRepository,
                                RatingService ratingService) {
        this.readingStatusRepository = readingStatusRepository;
        this.bookRepository = bookRepository;
        this.ratingService = ratingService;
    }

    @Transactional
    public void setUserStatus(Long userId, Long bookId, String status) {
        if (status == null) throw new IllegalArgumentException("Status null");

        ReadingStatus s = readingStatusRepository.findByUserIdAndBookId(userId, bookId)
                .orElseGet(() -> {
                    ReadingStatus ns = new ReadingStatus();
                    ns.setUserId(userId);
                    ns.setBookId(bookId);
                    return ns;
                });
        s.setStatus(status);
        s.setUpdatedAt(LocalDateTime.now());
        readingStatusRepository.save(s);

        updatePopularity(bookId);
    }

    @Transactional
    public void removeUserStatus(Long userId, Long bookId) {
        readingStatusRepository.findByUserIdAndBookId(userId, bookId)
                .ifPresent(readingStatusRepository::delete);

        updatePopularity(bookId);
    }

    private void updatePopularity(Long bookId) {
        Set<Long> uniqueUsers = new HashSet<>();
        Set<Long> ratingUserIds = ratingService.findUserIdsByBookId(bookId);
        Set<Long> statusUserIds = readingStatusRepository.findUserIdsByBookId(bookId);

        if (ratingUserIds != null) uniqueUsers.addAll(ratingUserIds);
        if (statusUserIds != null) uniqueUsers.addAll(statusUserIds);

        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new IllegalArgumentException("Book not found: " + bookId));
        book.setPopularity((long) uniqueUsers.size());
        bookRepository.save(book);
    }
    public Optional<String> findStatusByUserAndBook(Long userId, Long bookId) {
        return readingStatusRepository.findByUserIdAndBookId(userId, bookId)
                .map(ReadingStatus::getStatus);
    }


    public List<Book> findBooksByUserAndStatus(Long userId, String status) {
        return readingStatusRepository.findBooksByUserIdAndStatus(userId, status);
    }

    public Map<Long, String> findStatusesByUser(Long userId) {
        List<ReadingStatus> statuses = readingStatusRepository.findAllByUserId(userId);
        return statuses.stream()
                .collect(Collectors.toMap(ReadingStatus::getBookId, ReadingStatus::getStatus));
    }

    public Optional<Book> findBookById(Long bookId) {
        return bookRepository.findById(bookId);
    }

    public long countByBookIdAndStatus(Long bookId, String status) {
        return readingStatusRepository.countByBookIdAndStatus(bookId, status);
    }




}
