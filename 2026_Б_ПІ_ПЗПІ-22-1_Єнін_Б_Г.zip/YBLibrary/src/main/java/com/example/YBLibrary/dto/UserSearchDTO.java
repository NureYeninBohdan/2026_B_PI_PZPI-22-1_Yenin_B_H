package com.example.YBLibrary.dto;

public class UserSearchDTO {

    private Long id;
    private String username;
    private String avatarUrl;
    private boolean subscribed;

    public UserSearchDTO() {
    }

    public UserSearchDTO(Long id, String username, String avatarUrl, boolean subscribed) {
        this.id = id;
        this.username = username;
        this.avatarUrl = avatarUrl;
        this.subscribed = subscribed;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public boolean isSubscribed() {
        return subscribed;
    }

    public void setSubscribed(boolean subscribed) {
        this.subscribed = subscribed;
    }
}