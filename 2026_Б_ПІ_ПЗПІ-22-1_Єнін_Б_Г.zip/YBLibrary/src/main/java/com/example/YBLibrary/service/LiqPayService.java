package com.example.YBLibrary.service;

import com.example.YBLibrary.dto.LiqPayCheckoutForm;
import com.example.YBLibrary.service.SubscriptionService.SubscriptionPlan;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class LiqPayService {

    private final ObjectMapper objectMapper = new ObjectMapper();

    private static final DateTimeFormatter LIQPAY_DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Value("${liqpay.public-key}")
    private String publicKey;

    @Value("${liqpay.private-key}")
    private String privateKey;

    @Value("${liqpay.checkout-url:https://www.liqpay.ua/api/3/checkout}")
    private String checkoutUrl;

    @Value("${liqpay.api-url:https://www.liqpay.ua/api/request}")
    private String apiUrl;

    @Value("${liqpay.currency:UAH}")
    private String currency;

    @Value("${liqpay.result-url}")
    private String resultUrl;

    @Value("${liqpay.server-url}")
    private String serverUrl;

    @Value("${liqpay.sandbox:1}")
    private Integer sandbox;

    @Value("${liqpay.recurring.enabled:true}")
    private boolean recurringEnabled;

    public LiqPayCheckoutForm createSubscriptionCheckout(Long userId,
                                                         String username,
                                                         SubscriptionPlan plan) {
        if (userId == null) {
            throw new IllegalArgumentException("ID користувача не задано");
        }

        if (plan == null) {
            throw new IllegalArgumentException("План підписки не задано");
        }

        String orderId = buildOrderId(userId, plan);

        Map<String, Object> params = new LinkedHashMap<>();

        params.put("public_key", publicKey);
        params.put("version", "3");

        if (recurringEnabled) {
            params.put("action", "subscribe");
            params.put("subscribe", "1");
            params.put("subscribe_periodicity", getLiqPayPeriodicity(plan));
            params.put("subscribe_date_start", getNextChargeDate(plan));
        } else {
            params.put("action", "pay");
        }

        params.put("amount", plan.getAmountForLiqPay());
        params.put("currency", currency);
        params.put("description", "Підписка YBLibrary: " + plan.getTitle());
        params.put("order_id", orderId);
        params.put("result_url", resultUrl);
        params.put("server_url", serverUrl);
        params.put("sandbox", sandbox);

        params.put(
                "info",
                "userId=" + userId
                        + ";username=" + safeValue(username)
                        + ";planCode=" + plan.getCode()
                        + ";months=" + plan.getMonths()
                        + ";amount=" + plan.getAmountForLiqPay()
                        + ";orderId=" + orderId
                        + ";recurring=" + recurringEnabled
        );

        String data = toBase64Json(params);
        String signature = createSignature(data);

        return new LiqPayCheckoutForm(checkoutUrl, data, signature);
    }

    public JsonNode unsubscribeSubscription(String orderId) {
        if (orderId == null || orderId.isBlank()) {
            throw new IllegalArgumentException("order_id підписки LiqPay не задано");
        }

        Map<String, Object> params = new LinkedHashMap<>();

        params.put("public_key", publicKey);
        params.put("version", "3");
        params.put("action", "unsubscribe");
        params.put("order_id", orderId.trim());

        if (sandbox != null) {
            params.put("sandbox", sandbox);
        }

        return sendApiRequest(params);
    }

    public boolean isUnsubscribeSuccessful(JsonNode response) {
        if (response == null) {
            return false;
        }

        String status = response.path("status").asText("");
        String result = response.path("result").asText("");
        String action = response.path("action").asText("");

        return "success".equalsIgnoreCase(status)
                || "ok".equalsIgnoreCase(status)
                || "unsubscribed".equalsIgnoreCase(status)
                || "success".equalsIgnoreCase(result)
                || "ok".equalsIgnoreCase(result)
                || "unsubscribe".equalsIgnoreCase(action);
    }

    public boolean isCallbackSignatureValid(String data, String signature) {
        if (data == null || signature == null) {
            return false;
        }

        String expectedSignature = createSignature(data);
        return expectedSignature.equals(signature);
    }

    public JsonNode decodeCallbackData(String data) {
        try {
            byte[] decoded = Base64.getDecoder().decode(data);
            String json = new String(decoded, StandardCharsets.UTF_8);
            return objectMapper.readTree(json);
        } catch (Exception e) {
            throw new RuntimeException("Не вдалося розшифрувати callback data від LiqPay", e);
        }
    }

    private JsonNode sendApiRequest(Map<String, Object> params) {
        try {
            String data = toBase64Json(params);
            String signature = createSignature(data);

            String body = "data=" + URLEncoder.encode(data, StandardCharsets.UTF_8)
                    + "&signature=" + URLEncoder.encode(signature, StandardCharsets.UTF_8);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(apiUrl))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                    .build();

            HttpClient client = HttpClient.newHttpClient();

            HttpResponse<String> response = client.send(
                    request,
                    HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8)
            );

            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new RuntimeException(
                        "LiqPay API повернув HTTP "
                                + response.statusCode()
                                + ": "
                                + response.body()
                );
            }

            return objectMapper.readTree(response.body());
        } catch (Exception e) {
            throw new RuntimeException("Помилка під час запиту до LiqPay API", e);
        }
    }

    private String getLiqPayPeriodicity(SubscriptionPlan plan) {
        if (plan.getLiqPayPeriodicity() != null && !plan.getLiqPayPeriodicity().isBlank()) {
            return plan.getLiqPayPeriodicity();
        }

        if (plan.getMonths() >= 12) {
            return "year";
        }

        return "month";
    }

    private String getNextChargeDate(SubscriptionPlan plan) {
        LocalDate nextChargeDate = LocalDate.now()
                .plusMonths(plan.getMonths())
                .plusDays(1);

        return nextChargeDate
                .atStartOfDay()
                .format(LIQPAY_DATE_TIME_FORMATTER);
    }

    private String buildOrderId(Long userId, SubscriptionPlan plan) {
        return "subscription_"
                + userId
                + "_"
                + plan.getCode()
                + "_"
                + System.currentTimeMillis();
    }

    private String toBase64Json(Map<String, Object> params) {
        try {
            String json = objectMapper.writeValueAsString(params);
            return Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            throw new RuntimeException("Не вдалося сформувати data для LiqPay", e);
        }
    }

    private String createSignature(String data) {
        try {
            String signString = privateKey + data + privateKey;
            MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
            byte[] digest = sha1.digest(signString.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(digest);
        } catch (Exception e) {
            throw new RuntimeException("Не вдалося сформувати signature для LiqPay", e);
        }
    }

    private String safeValue(String value) {
        return value == null ? "" : value.replace(";", "").trim();
    }
}