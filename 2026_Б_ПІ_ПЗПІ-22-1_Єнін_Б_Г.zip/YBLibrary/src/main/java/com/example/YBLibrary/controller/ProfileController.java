package com.example.YBLibrary.controller;

import com.example.YBLibrary.model.Book;
import com.example.YBLibrary.model.User;
import com.example.YBLibrary.service.BookFilterService;
import com.example.YBLibrary.service.CustomUserDetails;
import com.example.YBLibrary.service.RatingService;
import com.example.YBLibrary.service.ReadingStatusService;
import com.example.YBLibrary.service.SubscriptionService;
import com.example.YBLibrary.service.UserService;
import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.geometry.Positions;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.*;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.*;

@Controller
public class ProfileController {

    private final ReadingStatusService readingStatusService;
    private final RatingService ratingService;
    private final UserService userService;
    private final BookFilterService bookFilterService;
    private final SubscriptionService subscriptionService;

    private static final String AVATAR_UPLOAD_DIR = "uploads/avatars";
    private static final String NO_AVATAR_FILENAME = "No Avatar.jpeg";
    private static final String NO_AVATAR_PATH = "/uploads/avatars/" + NO_AVATAR_FILENAME;

    public ProfileController(ReadingStatusService readingStatusService,
                             RatingService ratingService,
                             UserService userService,
                             BookFilterService bookFilterService,
                             SubscriptionService subscriptionService) {
        this.readingStatusService = readingStatusService;
        this.ratingService = ratingService;
        this.userService = userService;
        this.bookFilterService = bookFilterService;
        this.subscriptionService = subscriptionService;
    }

    @GetMapping("/profile")
    public String showProfile(@AuthenticationPrincipal CustomUserDetails currentUser,
                              @RequestParam(name = "avatarUpdated", required = false) Long avatarUpdated,
                              @RequestParam(name = "status", required = false, defaultValue = "all") String status,
                              @RequestParam(name = "page", required = false, defaultValue = "0") int page,
                              @RequestParam(name = "size", required = false, defaultValue = "20") int size,
                              Model model) {
        if (currentUser == null) {
            return "redirect:/login";
        }

        User user = userService.findByUsername(currentUser.getUsername());
        Long userId = user.getUserId();

        addProfileAttributes(
                model,
                user,
                userId,
                true,
                avatarUpdated,
                status,
                page,
                size
        );

        return "profile";
    }

    @GetMapping("/profile/{username}")
    public String viewUserProfile(@PathVariable String username,
                                  @AuthenticationPrincipal CustomUserDetails currentUser,
                                  @RequestParam(name = "status", required = false, defaultValue = "all") String status,
                                  @RequestParam(name = "page", required = false, defaultValue = "0") int page,
                                  @RequestParam(name = "size", required = false, defaultValue = "20") int size,
                                  Model model) {
        User user = userService.findVerifiedByUsername(username);
        Long userId = user.getUserId();

        boolean isOwner = currentUser != null && currentUser.getUsername().equals(username);

        addProfileAttributes(
                model,
                user,
                userId,
                isOwner,
                null,
                status,
                page,
                size
        );

        return "profile";
    }

    private void addProfileAttributes(Model model,
                                      User user,
                                      Long userId,
                                      boolean isOwner,
                                      Long cacheBuster,
                                      String status,
                                      int page,
                                      int size) {
        List<Book> readingBooks = readingStatusService.findBooksByUserAndStatus(userId, "Читаю");
        List<Book> plannedBooks = readingStatusService.findBooksByUserAndStatus(userId, "В планах");
        List<Book> readBooks = readingStatusService.findBooksByUserAndStatus(userId, "Прочитано");

        Map<Long, Integer> userRatings = ratingService.findRatingsByUser(userId);

        List<Book> displayedBooks = combinedBooks(readingBooks, plannedBooks, readBooks, status, userRatings);

        sortByRating(readingBooks, userRatings);
        sortByRating(plannedBooks, userRatings);
        sortByRating(readBooks, userRatings);
        sortByRating(displayedBooks, userRatings);

        Page<Book> pageObj = toPage(displayedBooks, page, size);

        Double averageUserRating = userRatings.isEmpty()
                ? null
                : Math.round(
                userRatings.values()
                        .stream()
                        .mapToInt(Integer::intValue)
                        .average()
                        .orElse(0.0) * 100.0
        ) / 100.0;

        LocalDateTime subscriptionEnd = subscriptionService.getSubscriptionEnd(userId);
        boolean profileIsSubscribed = subscriptionService.hasActiveSubscription(userId);

        model.addAttribute("user", user);
        model.addAttribute("readingBooks", readingBooks);
        model.addAttribute("plannedBooks", plannedBooks);
        model.addAttribute("readBooks", readBooks);
        model.addAttribute("allBooks", displayedBooks);
        model.addAttribute("page", pageObj);
        model.addAttribute("books", pageObj.getContent());
        model.addAttribute("size", size);
        model.addAttribute("bookStatuses", readingStatusService.findStatusesByUser(userId));
        model.addAttribute("userRatings", userRatings);
        model.addAttribute("averageUserRating", averageUserRating);
        model.addAttribute("cacheBuster", cacheBuster);
        model.addAttribute("isOwner", isOwner);
        model.addAttribute("status", status);
        model.addAttribute("subscriptionEnd", subscriptionEnd);
        model.addAttribute("profileIsSubscribed", profileIsSubscribed);
    }

    private List<Book> combinedBooks(List<Book> reading,
                                     List<Book> planned,
                                     List<Book> read,
                                     String status,
                                     Map<Long, Integer> userRatings) {
        if (!"all".equalsIgnoreCase(status)) {
            return switch (status) {
                case "Читаю" -> new ArrayList<>(reading);
                case "В планах" -> new ArrayList<>(planned);
                case "Прочитано" -> new ArrayList<>(read);
                default -> {
                    Set<Book> s = new LinkedHashSet<>();
                    s.addAll(reading);
                    s.addAll(planned);
                    s.addAll(read);
                    yield new ArrayList<>(s);
                }
            };
        }

        Set<Book> all = new LinkedHashSet<>();

        all.addAll(reading);
        all.addAll(planned);
        all.addAll(read);

        for (Long bookId : userRatings.keySet()) {
            boolean exists = all.stream().anyMatch(b -> b.getBookId().equals(bookId));

            if (!exists) {
                readingStatusService.findBookById(bookId).ifPresent(all::add);
            }
        }

        return new ArrayList<>(all);
    }

    private void sortByRating(List<Book> books, Map<Long, Integer> userRatings) {
        Comparator<Book> byTitle = Comparator.comparing(
                Book::getTitle,
                Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER)
        );

        Comparator<Book> byId = Comparator.comparing(
                Book::getBookId,
                Comparator.nullsLast(Long::compareTo)
        );

        Comparator<Book> byUserRatingDesc = Comparator
                .comparingInt((Book b) -> userRatings.getOrDefault(b.getBookId(), 0))
                .reversed()
                .thenComparing(byTitle)
                .thenComparing(byId);

        books.sort(byUserRatingDesc);
    }

    private Page<Book> toPage(List<Book> items, int page, int size) {
        if (size <= 0) {
            size = 20;
        }

        if (page < 0) {
            page = 0;
        }

        int total = items == null ? 0 : items.size();
        int from = Math.min(page * size, total);
        int to = Math.min(from + size, total);

        List<Book> content = (from < to)
                ? items.subList(from, to)
                : Collections.emptyList();

        return new PageImpl<>(content, PageRequest.of(page, size), total);
    }

    @PostMapping("/profile/upload-avatar")
    public String uploadAvatar(@RequestParam("avatar") MultipartFile file,
                               Principal principal,
                               RedirectAttributes redirectAttributes) {
        try {
            if (principal == null) {
                redirectAttributes.addFlashAttribute("error", "Неавторизований доступ");
                return "redirect:/login";
            }

            if (file.isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "Файл не вибрано");
                return "redirect:/profile";
            }

            String contentType = file.getContentType();

            if (contentType == null || !contentType.startsWith("image/")) {
                redirectAttributes.addFlashAttribute("error", "Можна завантажувати лише зображення");
                return "redirect:/profile";
            }

            User user = userService.findByUsername(principal.getName());

            Path uploadDir = Paths.get(AVATAR_UPLOAD_DIR);

            if (!Files.exists(uploadDir)) {
                Files.createDirectories(uploadDir);
            }

            deleteOldAvatarFile(user.getAvatarPath());

            String originalFileName = file.getOriginalFilename();

            if (originalFileName == null || originalFileName.isBlank()) {
                originalFileName = "avatar.jpg";
            }

            if (NO_AVATAR_FILENAME.equalsIgnoreCase(originalFileName)) {
                String extension = getFileExtension(originalFileName);
                originalFileName = "avatar_" + UUID.randomUUID() + extension;
            }

            String extension = getFileExtension(originalFileName);

            if (extension.isBlank()) {
                extension = ".jpg";
            }

            String fileName = UUID.randomUUID() + "_avatar" + extension;
            Path filePath = uploadDir.resolve(fileName);

            saveSquareAvatar(file, filePath);

            user.setAvatarPath("/uploads/avatars/" + fileName);
            userService.save(user);

            refreshAuthenticatedUser(user);

            redirectAttributes.addFlashAttribute("success", "Аватар оновлено");

            return "redirect:/profile?avatarUpdated=" + System.currentTimeMillis();
        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("error", "Помилка при завантаженні файлу");
            e.printStackTrace();
        }

        return "redirect:/profile";
    }

    @PostMapping("/profile/delete-avatar")
    public String deleteAvatar(Principal principal, RedirectAttributes redirectAttributes) {
        try {
            if (principal == null) {
                redirectAttributes.addFlashAttribute("error", "Неавторизований доступ");
                return "redirect:/login";
            }

            User user = userService.findByUsername(principal.getName());

            if (user.getAvatarPath() != null && !user.getAvatarPath().endsWith(NO_AVATAR_FILENAME)) {
                deleteOldAvatarFile(user.getAvatarPath());

                user.setAvatarPath(NO_AVATAR_PATH);
                userService.save(user);

                refreshAuthenticatedUser(user);

                redirectAttributes.addFlashAttribute("success", "Аватар видалено");

                return "redirect:/profile?avatarUpdated=" + System.currentTimeMillis();
            } else {
                redirectAttributes.addFlashAttribute("info", "Аватар відсутній або вже дефолтний");
            }
        } catch (IOException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("error", "Помилка при видаленні аватара");
        }

        return "redirect:/profile";
    }

    private void saveSquareAvatar(MultipartFile file, Path filePath) throws IOException {
        Thumbnails.of(file.getInputStream())
                .size(512, 512)
                .crop(Positions.CENTER)
                .outputQuality(0.85)
                .toFile(filePath.toFile());
    }

    private void deleteOldAvatarFile(String avatarPath) throws IOException {
        if (avatarPath == null || avatarPath.isBlank() || avatarPath.endsWith(NO_AVATAR_FILENAME)) {
            return;
        }

        String avatarFileName = Paths.get(avatarPath).getFileName().toString();
        Path avatarFilePath = Paths.get(AVATAR_UPLOAD_DIR).resolve(avatarFileName);

        Files.deleteIfExists(avatarFilePath);
    }

    private String getFileExtension(String filename) {
        if (filename == null) {
            return "";
        }

        int dotIdx = filename.lastIndexOf('.');

        if (dotIdx > 0 && dotIdx < filename.length() - 1) {
            return filename.substring(dotIdx);
        }

        return "";
    }

    private void refreshAuthenticatedUser(User user) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (auth != null && auth.getPrincipal() instanceof CustomUserDetails userDetails) {
            userDetails.setUser(user);

            UsernamePasswordAuthenticationToken newAuth = new UsernamePasswordAuthenticationToken(
                    userDetails,
                    auth.getCredentials(),
                    userDetails.getAuthorities()
            );

            SecurityContextHolder.getContext().setAuthentication(newAuth);
        }
    }
}