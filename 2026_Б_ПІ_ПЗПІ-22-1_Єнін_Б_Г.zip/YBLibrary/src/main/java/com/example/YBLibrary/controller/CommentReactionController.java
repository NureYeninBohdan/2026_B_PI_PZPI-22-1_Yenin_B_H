package com.example.YBLibrary.controller;

import com.example.YBLibrary.dto.CommentReactionDTO;
import com.example.YBLibrary.service.CommentReactionService;
import com.example.YBLibrary.service.CustomUserDetails;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/books/{bookId}/comments/{commentId}/reaction")
public class CommentReactionController {

    private final CommentReactionService commentReactionService;

    public CommentReactionController(CommentReactionService commentReactionService) {
        this.commentReactionService = commentReactionService;
    }

    @PostMapping
    public CommentReactionDTO toggleReaction(@PathVariable Long bookId,
                                             @PathVariable Long commentId,
                                             @RequestBody Map<String, String> body,
                                             Authentication authentication) {
        CustomUserDetails principal = extractPrincipal(authentication);

        String reactionType = body == null ? null : body.get("reactionType");

        return commentReactionService.toggleReaction(
                bookId,
                commentId,
                principal.getId(),
                reactionType
        );
    }

    private CustomUserDetails extractPrincipal(Authentication authentication) {
        if (authentication == null
                || !authentication.isAuthenticated()
                || !(authentication.getPrincipal() instanceof CustomUserDetails principal)) {
            throw new NotAuthenticatedException();
        }

        return principal;
    }

    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    private static class NotAuthenticatedException extends RuntimeException {
    }
}