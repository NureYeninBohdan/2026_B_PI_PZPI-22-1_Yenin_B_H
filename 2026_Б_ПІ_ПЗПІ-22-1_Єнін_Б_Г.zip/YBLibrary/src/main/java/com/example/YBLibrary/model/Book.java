package com.example.YBLibrary.model;

import jakarta.persistence.*;
import org.hibernate.annotations.Nationalized;

@Entity
@Table(name = "books")
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "book_id")
    private Long bookId;

    @Nationalized
    @Column(name = "title", nullable = false, length = 500)
    private String title;

    @Nationalized
    @Column(name = "author", length = 255)
    private String author;

    @Nationalized
    @Lob
    @Column(name = "description", columnDefinition = "NVARCHAR(MAX)")
    private String description;

    @Nationalized
    @Column(name = "cover_path", length = 255)
    private String coverPath;

    @Column(name = "average_rating", nullable = false)
    private Double averageRating = 0.0;

    @Column(name = "popularity", nullable = false)
    private Long popularity = 0L;

    @Nationalized
    @Column(name = "book_dump_id", length = 255)
    private String bookDumpId;

    @Nationalized
    @Column(name = "genre", length = 255)
    private String genre;

    @Column(name = "publish_year")
    private Integer publishYear;

    @Nationalized
    @Column(name = "file_path", length = 255)
    private String filePath;

    @Nationalized
    @Column(name = "access_level", nullable = false, length = 20)
    private String accessLevel = "FREE";

    public Book() {
    }

    public Book(String title, String author, String coverPath) {
        this.title = title;
        this.author = author;
        this.coverPath = coverPath;
        this.averageRating = 0.0;
        this.popularity = 0L;
        this.accessLevel = "FREE";
    }

    @PrePersist
    protected void onCreate() {
        normalizeDefaults();
    }

    @PreUpdate
    protected void onUpdate() {
        normalizeDefaults();
    }

    private void normalizeDefaults() {
        if (averageRating == null) {
            averageRating = 0.0;
        }

        if (popularity == null) {
            popularity = 0L;
        }

        if (accessLevel == null || accessLevel.isBlank()) {
            accessLevel = "FREE";
        }
    }

    public Long getBookId() {
        return bookId;
    }

    public void setBookId(Long bookId) {
        this.bookId = bookId;
    }

    public Long getId() {
        return bookId;
    }

    public void setId(Long id) {
        this.bookId = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCoverPath() {
        return coverPath;
    }

    public void setCoverPath(String coverPath) {
        this.coverPath = coverPath;
    }

    public Double getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(Double averageRating) {
        this.averageRating = averageRating;
    }

    public Long getPopularity() {
        return popularity;
    }

    public void setPopularity(Long popularity) {
        this.popularity = popularity;
    }

    public String getBookDumpId() {
        return bookDumpId;
    }

    public void setBookDumpId(String bookDumpId) {
        this.bookDumpId = bookDumpId;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public Integer getPublishYear() {
        return publishYear;
    }

    public void setPublishYear(Integer publishYear) {
        this.publishYear = publishYear;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getAccessLevel() {
        return accessLevel;
    }

    public void setAccessLevel(String accessLevel) {
        this.accessLevel = accessLevel;
    }
}