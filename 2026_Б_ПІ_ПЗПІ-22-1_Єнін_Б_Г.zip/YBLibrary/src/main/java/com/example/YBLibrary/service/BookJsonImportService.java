package com.example.YBLibrary.service;

import com.example.YBLibrary.dto.BookJsonImportDTO;
import com.example.YBLibrary.model.Book;
import com.example.YBLibrary.repository.BookRepository;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.file.Files;
import java.nio.file.Path;
import java.text.Normalizer;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

@Service
public class BookJsonImportService {

    private static final Logger logger = LoggerFactory.getLogger(BookJsonImportService.class);

    private static final String DEFAULT_COVER = "/uploads/covers/No Cover.jpg";
    private static final String ACCESS_FREE = "FREE";
    private static final String ACCESS_SUBSCRIPTION = "SUBSCRIPTION";

    private final BookRepository bookRepository;
    private final ObjectMapper objectMapper;

    private final AtomicBoolean importRunning = new AtomicBoolean(false);

    @PersistenceContext
    private EntityManager entityManager;

    @Value("${books.import.batch-size:100}")
    private int batchSize;

    @Value("${books.import.pause-ms:200}")
    private long pauseMs;

    @Value("${books.import.delete-file-after-finish:true}")
    private boolean deleteFileAfterFinish;

    public BookJsonImportService(BookRepository bookRepository,
                                 ObjectMapper objectMapper) {
        this.bookRepository = bookRepository;
        this.objectMapper = objectMapper;
    }

    public boolean isImportRunning() {
        return importRunning.get();
    }

    @Async("bookImportTaskExecutor")
    public void importBooksFromJsonFile(Path filePath, String originalFileName, String startedBy) {
        if (!importRunning.compareAndSet(false, true)) {
            logger.warn("Book JSON import was not started because another import is already running.");
            return;
        }

        long processed = 0;
        long created = 0;
        long skipped = 0;
        long failed = 0;

        LocalDateTime startedAt = LocalDateTime.now();

        logger.info("============================================================");
        logger.info("Book JSON import started.");
        logger.info("Original file: {}", originalFileName);
        logger.info("Saved file: {}", filePath);
        logger.info("Started by: {}", startedBy == null || startedBy.isBlank() ? "unknown" : startedBy);
        logger.info("Batch size: {}", normalizeBatchSize());
        logger.info("Pause between batches: {} ms", normalizePauseMs());
        logger.info("============================================================");

        List<BookJsonImportDTO> dtoBatch = new ArrayList<>(normalizeBatchSize());

        try {
            ObjectReader reader = objectMapper.readerFor(BookJsonImportDTO.class);

            try (var parser = objectMapper.getFactory().createParser(filePath.toFile())) {
                JsonToken firstToken = parser.nextToken();

                if (firstToken != JsonToken.START_ARRAY) {
                    throw new IllegalArgumentException("JSON-файл має містити масив книг: [ {...}, {...} ]");
                }

                while (parser.nextToken() == JsonToken.START_OBJECT) {
                    try {
                        BookJsonImportDTO dto = reader.readValue(parser);

                        processed++;

                        if (!isImportable(dto)) {
                            skipped++;
                        } else {
                            dtoBatch.add(dto);
                        }

                        if (dtoBatch.size() >= normalizeBatchSize()) {
                            ImportBatchResult result = saveBatch(dtoBatch);

                            created += result.created();
                            skipped += result.skipped();

                            dtoBatch.clear();

                            logProgress(processed, created, skipped, failed);
                            pauseIfNeeded();
                        }
                    } catch (Exception itemError) {
                        processed++;
                        failed++;

                        logger.warn(
                                "Failed to process book item near record {}. Reason: {}",
                                processed,
                                itemError.getMessage()
                        );

                        parser.skipChildren();
                    }
                }
            }

            if (!dtoBatch.isEmpty()) {
                ImportBatchResult result = saveBatch(dtoBatch);

                created += result.created();
                skipped += result.skipped();

                dtoBatch.clear();

                logProgress(processed, created, skipped, failed);
            }

            logger.info("============================================================");
            logger.info("Book JSON import finished successfully.");
            logger.info("Started at: {}", startedAt);
            logger.info("Finished at: {}", LocalDateTime.now());
            logger.info("Processed: {}", processed);
            logger.info("Created: {}", created);
            logger.info("Skipped: {}", skipped);
            logger.info("Failed: {}", failed);
            logger.info("============================================================");
        } catch (Exception e) {
            logger.error("Book JSON import failed. File: {}. Reason: {}", filePath, e.getMessage(), e);
        } finally {
            if (deleteFileAfterFinish) {
                deleteTemporaryFile(filePath);
            }

            importRunning.set(false);
        }
    }


    protected ImportBatchResult saveBatch(List<BookJsonImportDTO> dtoBatch) {
        if (dtoBatch == null || dtoBatch.isEmpty()) {
            return new ImportBatchResult(0, 0);
        }

        Set<String> dumpIds = new LinkedHashSet<>();

        for (BookJsonImportDTO dto : dtoBatch) {
            String dumpId = resolveBookDumpId(dto);

            if (dumpId != null && !dumpId.isBlank()) {
                dumpIds.add(dumpId);
            }
        }

        Set<String> existingDumpIds = dumpIds.isEmpty()
                ? Set.of()
                : bookRepository.findExistingBookDumpIds(dumpIds);

        List<Book> booksToSave = new ArrayList<>();
        long skipped = 0;

        for (BookJsonImportDTO dto : dtoBatch) {
            String dumpId = resolveBookDumpId(dto);

            if (dumpId == null || dumpId.isBlank()) {
                skipped++;
                continue;
            }

            if (existingDumpIds.contains(dumpId)) {
                skipped++;
                continue;
            }

            booksToSave.add(toBook(dto, dumpId));
        }

        if (!booksToSave.isEmpty()) {
            bookRepository.saveAllAndFlush(booksToSave);
            entityManager.clear();
        }

        return new ImportBatchResult(booksToSave.size(), skipped);
    }

    private Book toBook(BookJsonImportDTO dto, String bookDumpId) {
        Book book = new Book();

        book.setBookDumpId(bookDumpId);
        book.setTitle(limit(normalize(dto.getTitle()), 500));
        book.setAuthor(limit(normalize(dto.getAuthor()), 255));
        book.setDescription(normalize(dto.getDescription()));
        book.setCoverPath(resolveCoverPath(dto));
        book.setGenre(limit(normalize(dto.getGenre()), 255));
        book.setPublishYear(resolvePublishYear(dto.getPublishYear()));
        book.setFilePath(limit(normalize(dto.getFilePath()), 255));
        book.setAccessLevel(resolveAccessLevel(dto.getAccessLevel()));
        book.setAverageRating(0.0);
        book.setPopularity(0L);

        return book;
    }

    private boolean isImportable(BookJsonImportDTO dto) {
        if (dto == null) {
            return false;
        }

        String title = normalize(dto.getTitle());

        return title != null && !title.isBlank();
    }

    private String resolveBookDumpId(BookJsonImportDTO dto) {
        String explicitId = normalize(dto.getBookDumpId());

        if (explicitId != null && !explicitId.isBlank()) {
            return limit(explicitId, 255);
        }

        String title = normalize(dto.getTitle());

        if (title == null || title.isBlank()) {
            return null;
        }

        String author = normalize(dto.getAuthor());
        Integer publishYear = resolvePublishYear(dto.getPublishYear());

        String raw = title + "|" + (author == null ? "" : author) + "|" + (publishYear == null ? "" : publishYear);

        return limit("json_" + slugify(raw), 255);
    }

    private String resolveCoverPath(BookJsonImportDTO dto) {
        String coverPath = normalize(dto.getCoverPath());

        if (coverPath != null && !coverPath.isBlank()) {
            return limit(coverPath, 255);
        }

        String coverUrl = normalize(dto.getCoverUrl());

        if (coverUrl != null && !coverUrl.isBlank()) {
            return limit(coverUrl, 255);
        }

        return DEFAULT_COVER;
    }

    private Integer resolvePublishYear(Integer year) {
        if (year == null) {
            return null;
        }

        if (year < 0 || year > 2100) {
            return null;
        }

        return year;
    }

    private String resolveAccessLevel(String accessLevel) {
        String normalized = normalize(accessLevel);

        if (normalized == null || normalized.isBlank()) {
            return ACCESS_FREE;
        }

        String upper = normalized.toUpperCase();

        if (ACCESS_SUBSCRIPTION.equals(upper)) {
            return ACCESS_SUBSCRIPTION;
        }

        return ACCESS_FREE;
    }

    private int normalizeBatchSize() {
        if (batchSize < 10) {
            return 10;
        }

        if (batchSize > 500) {
            return 500;
        }

        return batchSize;
    }

    private long normalizePauseMs() {
        if (pauseMs < 0) {
            return 0;
        }

        if (pauseMs > 5000) {
            return 5000;
        }

        return pauseMs;
    }

    private void pauseIfNeeded() {
        long actualPause = normalizePauseMs();

        if (actualPause <= 0) {
            return;
        }

        try {
            Thread.sleep(actualPause);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.warn("Book JSON import pause was interrupted.");
        }
    }

    private void logProgress(long processed, long created, long skipped, long failed) {
        logger.info(
                "Book import progress. Processed: {}, Created: {}, Skipped: {}, Failed: {}",
                processed,
                created,
                skipped,
                failed
        );
    }

    private void deleteTemporaryFile(Path filePath) {
        if (filePath == null) {
            return;
        }

        try {
            Files.deleteIfExists(filePath);
            logger.info("Temporary import file deleted: {}", filePath);
        } catch (Exception e) {
            logger.warn("Could not delete temporary import file: {}. Reason: {}", filePath, e.getMessage());
        }
    }

    private String normalize(String value) {
        return value == null ? null : value.trim();
    }

    private String limit(String value, int maxLength) {
        if (value == null) {
            return null;
        }

        if (value.length() <= maxLength) {
            return value;
        }

        return value.substring(0, maxLength);
    }

    private String slugify(String value) {
        String normalized = Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase()
                .replaceAll("[^a-z0-9а-яіїєґ]+", "_")
                .replaceAll("_+", "_")
                .replaceAll("^_|_$", "");

        if (normalized.isBlank()) {
            return "book_" + System.currentTimeMillis();
        }

        return normalized;
    }

    private record ImportBatchResult(long created, long skipped) {
    }
}