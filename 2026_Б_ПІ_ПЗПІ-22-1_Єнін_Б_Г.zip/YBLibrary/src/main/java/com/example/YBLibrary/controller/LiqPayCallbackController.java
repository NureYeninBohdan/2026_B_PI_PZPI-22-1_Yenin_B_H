package com.example.YBLibrary.controller;

import com.example.YBLibrary.service.LiqPayService;
import com.example.YBLibrary.service.SubscriptionService;
import com.example.YBLibrary.service.SubscriptionService.SubscriptionPlan;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment/liqpay")
public class LiqPayCallbackController {

    private final LiqPayService liqPayService;
    private final SubscriptionService subscriptionService;

    public LiqPayCallbackController(LiqPayService liqPayService,
                                    SubscriptionService subscriptionService) {
        this.liqPayService = liqPayService;
        this.subscriptionService = subscriptionService;
    }

    @PostMapping("/callback")
    public ResponseEntity<String> handleCallback(@RequestParam("data") String data,
                                                 @RequestParam("signature") String signature) {

        if (!liqPayService.isCallbackSignatureValid(data, signature)) {
            return ResponseEntity.badRequest().body("Invalid signature");
        }

        JsonNode callbackData = liqPayService.decodeCallbackData(data);

        String status = callbackData.path("status").asText("");
        String action = callbackData.path("action").asText("");
        String orderId = callbackData.path("order_id").asText("");
        String liqpayOrderId = callbackData.path("liqpay_order_id").asText("");
        String paymentId = callbackData.path("payment_id").asText("");
        String info = callbackData.path("info").asText("");

        System.out.println("LiqPay callback:");
        System.out.println("status = " + status);
        System.out.println("action = " + action);
        System.out.println("orderId = " + orderId);
        System.out.println("liqpayOrderId = " + liqpayOrderId);
        System.out.println("paymentId = " + paymentId);
        System.out.println("info = " + info);
        System.out.println(callbackData.toPrettyString());

        Long userId = extractLongValueFromInfo(info, "userId");
        String planCode = extractStringValueFromInfo(info, "planCode");

        if (userId == null) {
            return ResponseEntity.badRequest().body("User ID not found in payment info");
        }

        SubscriptionPlan plan = subscriptionService.getPlanByCode(planCode);

        if (isSubscriptionCreated(action, status)) {
            subscriptionService.activateSubscription(userId, plan, orderId);



            System.out.println(
                    "Підписку активовано для userId="
                            + userId
                            + ", plan="
                            + plan.getTitle()
                            + ", orderId="
                            + orderId
            );

            return ResponseEntity.ok("OK");
        }

        if (isRegularPaymentSuccess(action, status)) {

            subscriptionService.extendSubscriptionAfterRecurringPayment(userId, plan, orderId);

            System.out.println(
                    "Підписку продовжено регулярним платежем для userId="
                            + userId
                            + ", plan="
                            + plan.getTitle()
                            + ", orderId="
                            + orderId
            );

            return ResponseEntity.ok("OK");
        }

        if (isUnsubscribed(action, status)) {

            subscriptionService.markAutoRenewCancelledFromLiqPay(userId);

            System.out.println(
                    "Автопоновлення скасовано через LiqPay для userId="
                            + userId
                            + ", orderId="
                            + orderId
            );

            return ResponseEntity.ok("OK");
        }

        if (isFailedPaymentStatus(status)) {

            subscriptionService.handleRecurringPaymentFailure(userId, orderId, status);

            System.out.println(
                    "Невдалий платіж LiqPay для userId="
                            + userId
                            + ", status="
                            + status
                            + ", orderId="
                            + orderId
            );

            return ResponseEntity.ok("OK");
        }

        System.out.println("Callback отримано, але статус не потребує змін у підписці.");

        return ResponseEntity.ok("OK");
    }

    private boolean isSubscriptionCreated(String action, String status) {
        boolean subscribeAction = "subscribe".equalsIgnoreCase(action)
                || action == null
                || action.isBlank();

        return subscribeAction && isSuccessfulPaymentStatus(status);
    }

    private boolean isRegularPaymentSuccess(String action, String status) {
        return "regular".equalsIgnoreCase(action)
                && isSuccessfulPaymentStatus(status);
    }

    private boolean isUnsubscribed(String action, String status) {
        return "unsubscribe".equalsIgnoreCase(action)
                || "unsubscribed".equalsIgnoreCase(status);
    }

    private boolean isSuccessfulPaymentStatus(String status) {
        return "success".equalsIgnoreCase(status)
                || "sandbox".equalsIgnoreCase(status)
                || "subscribed".equalsIgnoreCase(status);
    }

    private boolean isFailedPaymentStatus(String status) {
        return "failure".equalsIgnoreCase(status)
                || "error".equalsIgnoreCase(status)
                || "reversed".equalsIgnoreCase(status);
    }

    private Long extractLongValueFromInfo(String info, String key) {
        String rawValue = extractStringValueFromInfo(info, key);

        if (rawValue == null || rawValue.isBlank()) {
            return null;
        }

        try {
            return Long.parseLong(rawValue);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String extractStringValueFromInfo(String info, String key) {
        if (info == null || info.isBlank() || key == null || key.isBlank()) {
            return null;
        }

        String[] parts = info.split(";");

        for (String part : parts) {
            String trimmed = part.trim();
            String prefix = key + "=";

            if (trimmed.startsWith(prefix)) {
                return trimmed.substring(prefix.length()).trim();
            }
        }

        return null;
    }
}