package com.example.YBLibrary.controller;

import com.example.YBLibrary.dto.LiqPayCheckoutForm;
import com.example.YBLibrary.service.CustomUserDetails;
import com.example.YBLibrary.service.LiqPayService;
import com.example.YBLibrary.service.SubscriptionService;
import com.example.YBLibrary.service.SubscriptionService.SubscriptionPlan;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Controller
public class SubscriptionController {

    private final LiqPayService liqPayService;
    private final SubscriptionService subscriptionService;

    private static final DateTimeFormatter SUBSCRIPTION_DATE_FORMATTER =
            DateTimeFormatter.ofPattern("dd.MM.yyyy");

    public SubscriptionController(LiqPayService liqPayService,
                                  SubscriptionService subscriptionService) {
        this.liqPayService = liqPayService;
        this.subscriptionService = subscriptionService;
    }

    @GetMapping("/subscription")
    public String showSubscriptionPage(@AuthenticationPrincipal CustomUserDetails currentUser,
                                       Model model) {
        addSubscriptionPageAttributes(model, currentUser);
        model.addAttribute("paymentSuccess", false);

        return "subscription";
    }

    @PostMapping("/subscription/checkout")
    public String checkoutSubscription(@AuthenticationPrincipal CustomUserDetails currentUser,
                                       @RequestParam(defaultValue = "MONTHLY") String planCode,
                                       Model model) {
        if (currentUser == null) {
            return "redirect:/login";
        }

        SubscriptionPlan plan = subscriptionService.getPlanByCode(planCode);

        LiqPayCheckoutForm form = liqPayService.createSubscriptionCheckout(
                currentUser.getId(),
                currentUser.getUsername(),
                plan
        );

        model.addAttribute("checkoutUrl", form.getCheckoutUrl());
        model.addAttribute("data", form.getData());
        model.addAttribute("signature", form.getSignature());

        return "liqpay-redirect";
    }

    @GetMapping("/subscription/result")
    public String subscriptionResult(@AuthenticationPrincipal CustomUserDetails currentUser,
                                     Model model) {
        boolean paymentSuccess = currentUser != null
                && subscriptionService.hasActiveSubscription(currentUser.getId());

        addSubscriptionPageAttributes(model, currentUser);
        model.addAttribute("paymentSuccess", paymentSuccess);

        return "subscription";
    }

    private void addSubscriptionPageAttributes(Model model, CustomUserDetails currentUser) {
        model.addAttribute("subscriptionEnd", getFormattedSubscriptionEnd(currentUser));
        model.addAttribute("currentSubscriptionPlanTitle", getCurrentSubscriptionPlanTitle(currentUser));
        model.addAttribute("subscriptionAutoRenew", getSubscriptionAutoRenew(currentUser));
    }

    private String getFormattedSubscriptionEnd(CustomUserDetails currentUser) {
        if (currentUser == null) {
            return null;
        }

        LocalDateTime subscriptionEnd = subscriptionService.getSubscriptionEnd(currentUser.getId());

        if (subscriptionEnd == null) {
            return null;
        }

        return subscriptionEnd.format(SUBSCRIPTION_DATE_FORMATTER);
    }

    private String getCurrentSubscriptionPlanTitle(CustomUserDetails currentUser) {
        if (currentUser == null) {
            return null;
        }

        String title = subscriptionService.getSubscriptionPlanTitle(currentUser.getId());

        if (title == null || title.isBlank()) {
            return "Активна підписка";
        }

        return title;
    }

    private boolean getSubscriptionAutoRenew(CustomUserDetails currentUser) {
        return currentUser != null
                && subscriptionService.isAutoRenewEnabled(currentUser.getId());
    }
}