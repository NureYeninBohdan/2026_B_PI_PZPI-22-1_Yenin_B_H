package com.example.YBLibrary.controller;

import com.example.YBLibrary.service.EmailService;
import com.example.YBLibrary.service.EmailTemplateService;
import com.example.YBLibrary.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Controller
public class EmailController {

    private static final Logger logger = LoggerFactory.getLogger(EmailController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private EmailTemplateService emailTemplateService;

    @Value("${app.base-url}")
    private String appBaseUrl;

    @GetMapping("/password-recovery")
    public String showRecoveryForm() {
        return "password-recovery";
    }

    @PostMapping("/password-recovery")
    public String handleRecovery(@RequestParam String email,
                                 Model model) {
        String normalizedEmail = normalize(email);
        String maskedEmail = userService.maskEmail(normalizedEmail);

        logger.info("Отримано запит на відновлення паролю для email: {}", maskedEmail);

        if (!userService.existsByEmail(normalizedEmail)) {
            logger.warn("Користувач з email {} не знайдений", maskedEmail);
            model.addAttribute("errorMessage", "Користувача з таким email не знайдено.");
            return "password-recovery";
        }

        String token = userService.createPasswordResetToken(normalizedEmail);

        String resetLink = buildPasswordResetLink(token);

        logger.info("Посилання для скидання паролю сформовано для email: {}", maskedEmail);

        String subject = "Відновлення паролю в YBLibrary";

        String greeting = "Запит на відновлення доступу";

        String message = "Ми отримали запит на скидання паролю для акаунта YBLibrary, прив’язаного до адреси "
                + maskedEmail + ".";

        String secondaryMessage = "Посилання діє протягом 1 години. "
                + "Якщо ви не запитували відновлення паролю, просто проігноруйте цей лист.";

        String htmlContent = emailTemplateService.buildActionEmail(
                "Відновлення паролю",
                greeting,
                message,
                "Скинути пароль",
                resetLink,
                secondaryMessage
        );

        String plainTextContent = emailTemplateService.buildPlainTextActionEmail(
                greeting,
                message,
                resetLink,
                secondaryMessage
        );

        boolean mailSent = emailService.sendHtmlEmail(
                normalizedEmail,
                subject,
                htmlContent,
                plainTextContent
        );

        if (!mailSent) {
            logger.error("Не вдалося відправити лист на email {}", maskedEmail);
            model.addAttribute("errorMessage", "Не вдалося відправити лист. Спробуйте пізніше.");
            return "password-recovery";
        }

        logger.info("Лист для відновлення паролю успішно відправлено на {}", maskedEmail);
        model.addAttribute("successMessage", "Лист для відновлення паролю відправлено на " + maskedEmail + ".");

        return "password-recovery";
    }

    private String buildPasswordResetLink(String token) {
        String normalizedBaseUrl = appBaseUrl == null ? "" : appBaseUrl.trim();

        if (normalizedBaseUrl.endsWith("/")) {
            normalizedBaseUrl = normalizedBaseUrl.substring(0, normalizedBaseUrl.length() - 1);
        }

        String encodedToken = URLEncoder.encode(token, StandardCharsets.UTF_8);

        return normalizedBaseUrl + "/reset-password?token=" + encodedToken;
    }

    private String normalize(String value) {
        return value == null ? null : value.trim();
    }
}